--[[
    GRM Arrest System v1.0.0
    Камеры ареста, группы заключённых, точки камер, /arrest и /unarrest.
]]

if SERVER then AddCSLuaFile() end

GRM = GRM or {}
GRM.Arrest = GRM.Arrest or {}
local A = GRM.Arrest
A.Version = "1.0.0"
A.File = "grm_arrest.json"
A.Cfg = A.Cfg or {
    model = "models/player/Group03/male_07.mdl",
    groups = {
        criminals = { name = "Уголовники", model = "models/player/Group03/male_07.mdl" },
        political = { name = "Политические", model = "models/player/Group03/male_04.mdl" },
        guardhouse = { name = "Гауптвахта", model = "models/player/Group01/male_07.mdl" },
    },
    cameras = {},
    spawns = {},
}

local function key(ply)
    if IsValid(ply) and ply:IsPlayer() then
        if GRM.Identity and GRM.Identity.CharacterKey then return GRM.Identity.CharacterKey(ply) end
        return tostring(ply:SteamID64() or ply:SteamID() or "") .. ":char1"
    end
    return tostring(ply or "")
end

local function save()
    if SERVER then file.Write(A.File, util.TableToJSON(A.Cfg, true)) end
end

local function load()
    if not SERVER or not file.Exists(A.File, "DATA") then return end
    local ok, t = pcall(util.JSONToTable, file.Read(A.File, "DATA") or "", false, true)
    if ok and istable(t) then
        for k, v in pairs(t) do A.Cfg[k] = v end
    end
    A.Cfg.groups = istable(A.Cfg.groups) and A.Cfg.groups or {}
    A.Cfg.cameras = istable(A.Cfg.cameras) and A.Cfg.cameras or {}
    A.Cfg.spawns = istable(A.Cfg.spawns) and A.Cfg.spawns or {}
end

    local function group(id)
        return A.Cfg.groups[tostring(id or "")] or A.Cfg.groups.criminals
    end

    if SERVER then
    util.AddNetworkString("GRM_Arrest_Admin")
    util.AddNetworkString("GRM_Arrest_AdminData")
    util.AddNetworkString("GRM_Arrest_AdminAction")
    util.AddNetworkString("GRM_Arrest_Event")

    load()

    local function announce(event, targetName, groupName)
        net.Start("GRM_Arrest_Event")
            net.WriteString(event or "")
            net.WriteString(targetName or "")
            net.WriteString(groupName or "")
        net.Broadcast()
    end

    local function vec(t) return Vector(tonumber(t.x) or 0, tonumber(t.y) or 0, tonumber(t.z) or 0) end
    local function ang(t) return Angle(tonumber(t.p) or 0, tonumber(t.y) or 0, tonumber(t.r) or 0) end
    local function vdata(v) return { x = v.x, y = v.y, z = v.z } end
    local function adata(a) return { p = a.p, y = a.y, r = a.r } end

    local function spawnCamera(rec)
        local ent = ents.Create("grm_arrest_camera")
        if not IsValid(ent) then return nil end
        ent:SetPos(vec(rec.pos)) ent:SetAngles(ang(rec.ang))
        ent:Spawn() ent:Activate()
        ent:SetCameraID(rec.id or "")
        ent:SetCameraName(rec.name or rec.id or "Камера")
        ent:SetArrestGroup(rec.group or "criminals")
        ent.GRMArrestID = rec.id
        local phys = ent:GetPhysicsObject()
        if IsValid(phys) then phys:EnableMotion(false) end
        return ent
    end

    local function loadCameras()
        for _, ent in ipairs(ents.FindByClass("grm_arrest_camera")) do ent:Remove() end
        for _, rec in ipairs(A.Cfg.cameras or {}) do if istable(rec) then spawnCamera(rec) end end
    end

    function A.OpenAdmin(ply)
        if not IsValid(ply) or not ply:IsSuperAdmin() then return end
        net.Start("GRM_Arrest_AdminData")
            net.WriteTable(A.Cfg)
        net.Send(ply)
    end

    local function nearestPlayer(ply)
        local tr = ply:GetEyeTrace()
        local target = tr and tr.Entity
        if IsValid(target) and target:IsPlayer() and target ~= ply and ply:GetPos():DistToSqr(target:GetPos()) <= 220 * 220 then return target end
        return nil
    end

    local function chooseCamera(groupID)
        for _, rec in ipairs(A.Cfg.cameras or {}) do
            if tostring(rec.group or "criminals") == tostring(groupID) then return rec end
        end
        return A.Cfg.cameras[1]
    end

    local function chooseSpawn(camera)
        if camera and camera.spawnID then
            for _, rec in ipairs(A.Cfg.spawns or {}) do if rec.id == camera.spawnID then return rec end end
        end
        return A.Cfg.spawns[1]
    end

    function A.ArrestPlayer(actor, target, groupID)
        if not IsValid(actor) or not IsValid(target) then return false, "Цель не найдена" end
        local HC = GRM.Handcuffs
        if not (HC and HC.IsCuffed and HC.IsCuffed(target)) then return false, "Сначала наденьте на человека наручники" end
        if target:GetNWBool("GRM_Arrested", false) then return false, "Человек уже арестован" end
        local cam = chooseCamera(groupID)
        if not cam then return false, "Для этой группы не настроена камера ареста" end
        local sp = chooseSpawn(cam)
        if not sp then return false, "Для камеры не назначена точка арестованного" end
        local g = group(groupID)
        target.GRM_ArrestOriginalModel = target:GetModel()
        target.GRM_ArrestOriginalSkin = target:GetSkin()
        target.GRM_ArrestOriginalBodygroups = {}
        for i = 0, (target:GetNumBodyGroups() or 0) - 1 do target.GRM_ArrestOriginalBodygroups[i] = target:GetBodygroup(i) end
        target:SetNWBool("GRM_Arrested", true)
        target:SetNWString("GRM_ArrestGroup", groupID or "criminals")
        target:SetNWString("GRM_ArrestGroupName", g.name or groupID or "Арестованный")
        if isstring(g.model) and g.model:match("^models/.+%.mdl$") then target:SetModel(g.model) end
        target:SetSkin(math.max(0, math.floor(tonumber(g.skin) or 0)))
        for group, value in pairs(g.bodygroups or {}) do target:SetBodygroup(tonumber(group) or 0, tonumber(value) or 0) end
        target:SetPos(vec(sp.pos))
        target:SetEyeAngles(ang(sp.ang or { p = 0, y = 0, r = 0 }))
        target:Freeze(false)
        if GRM.Notify then GRM.Notify(target, "Вы арестованы: " .. tostring(g.name), 255, 150, 100) end
        actor:ChatPrint("[Арест] Арестованный отправлен в: " .. tostring(g.name))
        announce("arrest", target:Nick(), g.name or groupID or "Арестованный")
        return true
    end

    function A.UnarrestPlayer(actor, target)
        if not IsValid(target) or not target:GetNWBool("GRM_Arrested", false) then return false end
        target:SetNWBool("GRM_Arrested", false)
        target:SetNWString("GRM_ArrestGroup", "")
        target:SetNWString("GRM_ArrestGroupName", "")
        if target.GRM_ArrestOriginalModel and util.IsValidModel(target.GRM_ArrestOriginalModel) then target:SetModel(target.GRM_ArrestOriginalModel) end
        target:SetSkin(tonumber(target.GRM_ArrestOriginalSkin) or 0)
        for group, value in pairs(target.GRM_ArrestOriginalBodygroups or {}) do target:SetBodygroup(tonumber(group) or 0, tonumber(value) or 0) end
        target.GRM_ArrestOriginalModel = nil
        target.GRM_ArrestOriginalSkin = nil
        target.GRM_ArrestOriginalBodygroups = nil
        if GRM.Notify then GRM.Notify(target, "Вы освобождены.", 120, 220, 140) end
        announce("unarrest", target:Nick(), "")
        return true
    end

    hook.Add("CanPlayerSuicide", "GRM_Arrest_BlockSuicide", function(ply)
        if IsValid(ply) and ply:GetNWBool("GRM_Arrested", false) then
            if GRM.Notify then GRM.Notify(ply, "Самоубийство во время ареста запрещено.", 255, 100, 100) end
            return false
        end
        -- Запрещаем консольный kill для всех игроков RP-сервера.
        if IsValid(ply) and not ply:IsSuperAdmin() then
            if GRM.Notify then GRM.Notify(ply, "Команда kill запрещена.", 255, 100, 100) end
            return false
        end
    end)

    hook.Add("PlayerSay", "GRM_Arrest_Commands", function(ply, text)
        local msg = string.Trim(text or "")
        local low = string.lower(msg)
        if low == "/arrest" or low:sub(1, 8) == "/arrest " then
            local gid = string.Trim(msg:sub(8))
            if gid == "" then gid = "criminals" end
            local target = nearestPlayer(ply)
            local ok, err = A.ArrestPlayer(ply, target, gid)
            if not ok then ply:ChatPrint("[Арест] " .. tostring(err)) end
            return ""
        end
        if low == "/unarrest" then
            local target = nearestPlayer(ply)
            if not A.UnarrestPlayer(ply, target) then ply:ChatPrint("[Арест] Цель не арестована.") end
            return ""
        end
    end)

    net.Receive("GRM_Arrest_Admin", function(_, ply) A.OpenAdmin(ply) end)
    net.Receive("GRM_Arrest_AdminAction", function(_, ply)
        if not IsValid(ply) or not ply:IsSuperAdmin() then return end
        local action = net.ReadString()
        local id = string.Trim(net.ReadString() or "")
        if action == "add_camera" then
            local tr = ply:GetEyeTrace()
            local rec = { id = id ~= "" and id or ("cam_" .. os.time()), name = id ~= "" and id or ("Камера " .. tostring(#A.Cfg.cameras + 1)), group = "criminals", pos = vdata(tr.HitPos), ang = adata(Angle(0, ply:EyeAngles().y, 0)), spawnID = "" }
            A.Cfg.cameras[#A.Cfg.cameras + 1] = rec
            spawnCamera(rec) save()
        elseif action == "delete_camera" then
            for i = #A.Cfg.cameras, 1, -1 do
                local cam = A.Cfg.cameras[i]
                if tostring(cam.id) == id then
                    for _, ent in ipairs(ents.FindByClass("grm_arrest_camera")) do
                        if ent.GRMArrestID == cam.id then ent:Remove() end
                    end
                    table.remove(A.Cfg.cameras, i)
                    break
                end
            end
            save()
        elseif action == "add_spawn" then
            local rec = { id = id ~= "" and id or ("spawn_" .. os.time()), name = id ~= "" and id or ("Точка ареста " .. tostring(#A.Cfg.spawns + 1)), pos = vdata(ply:GetPos()), ang = adata(ply:EyeAngles()) }
            A.Cfg.spawns[#A.Cfg.spawns + 1] = rec save()
        elseif action == "delete_spawn" then
            for i = #A.Cfg.spawns, 1, -1 do
                if tostring(A.Cfg.spawns[i].id) == id then
                    table.remove(A.Cfg.spawns, i)
                    break
                end
            end
            for _, cam in ipairs(A.Cfg.cameras or {}) do
                if tostring(cam.spawnID or "") == id then cam.spawnID = "" end
            end
            save()
        elseif action == "set_group" then
            local name = string.Trim(net.ReadString() or "")
            local model = string.Trim(net.ReadString() or "")
            if id:match("^[%w_%-]+$") and name ~= "" then
                A.Cfg.groups[id] = A.Cfg.groups[id] or {}
                A.Cfg.groups[id].name = name
                if model ~= "" and util.IsValidModel(model) then A.Cfg.groups[id].model = model end
                save()
            end
        elseif action == "set_group_model" then
            local model = string.Trim(net.ReadString() or "")
            if A.Cfg.groups[id] and model:match("^models/.+%.mdl$") then
                A.Cfg.groups[id].model = model
                save()
            end
        elseif action == "set_group_data" then
            local data = net.ReadTable() or {}
            local model = string.Trim(tostring(data.model or ""))
            if A.Cfg.groups[id] and model:match("^models/.+%.mdl$") then
                A.Cfg.groups[id].model = model
                A.Cfg.groups[id].skin = math.max(0, math.floor(tonumber(data.skin) or 0))
                A.Cfg.groups[id].bodygroups = {}
                for group, value in pairs(data.bodygroups or {}) do
                    local gi, vi = tonumber(group), tonumber(value)
                    if gi and vi then A.Cfg.groups[id].bodygroups[gi] = vi end
                end
                save()
            end
        elseif action == "set_camera_group" then
            local groupID = string.Trim(net.ReadString() or "")
            if A.Cfg.groups[groupID] then
                for _, cam in ipairs(A.Cfg.cameras) do if cam.id == id then cam.group = groupID end end
                save()
            end
        elseif action == "assign_camera_spawn" then
            local spawnID = string.Trim(net.ReadString() or "")
            for _, cam in ipairs(A.Cfg.cameras) do if cam.id == id then cam.spawnID = spawnID end end
            save()
        elseif action == "reload" then
            loadCameras()
        end
        A.OpenAdmin(ply)
    end)

    concommand.Add("grm_arrest_admin", function(ply) A.OpenAdmin(ply) end)
    concommand.Add("grm_arrest_reload", function(ply) if not IsValid(ply) or ply:IsSuperAdmin() then loadCameras() end end)
    hook.Add("InitPostEntity", "GRM_Arrest_LoadCameras", function() timer.Simple(2, loadCameras) end)
    hook.Add("ShutDown", "GRM_Arrest_Save", save)
end

if CLIENT then
    net.Receive("GRM_Arrest_Event", function()
        local event = net.ReadString()
        local targetName = net.ReadString()
        local groupName = net.ReadString()
        if event == "arrest" then
            notification.AddLegacy("Арестован: " .. targetName .. "  •  помещён в камеру: " .. groupName, NOTIFY_ERROR, 7)
            surface.PlaySound("buttons/button10.wav")
        elseif event == "unarrest" then
            notification.AddLegacy("Освобождён: " .. targetName, NOTIFY_GENERIC, 6)
            surface.PlaySound("buttons/button14.wav")
        end
    end)

    surface.CreateFont("GRMArrestTitle", { font = "Roboto", size = 22, weight = 900, extended = true })
    surface.CreateFont("GRMArrestHeading", { font = "Roboto", size = 16, weight = 800, extended = true })
    surface.CreateFont("GRMArrestBody", { font = "Roboto", size = 14, weight = 500, extended = true })
    surface.CreateFont("GRMArrestSmall", { font = "Roboto", size = 12, weight = 500, extended = true })

    local UI = {
        bg = Color(12, 17, 25, 252), header = Color(22, 29, 41, 255), sidebar = Color(17, 24, 35, 255),
        card = Color(25, 34, 48, 255), card2 = Color(30, 41, 57, 255), line = Color(54, 68, 89, 220),
        text = Color(239, 244, 250), dim = Color(157, 171, 190), accent = Color(72, 153, 255),
        green = Color(70, 201, 128), orange = Color(241, 157, 78), red = Color(222, 87, 91),
    }

    local function label(parent, text, font, color)
        local l = vgui.Create("DLabel", parent)
        l:SetText(text or "") l:SetFont(font or "GRMArrestBody") l:SetTextColor(color or UI.text)
        l:SetWrap(true)
        return l
    end

    local function button(parent, text, color, tall)
        local b = vgui.Create("DButton", parent)
        b:SetText(text or "") b:SetFont("GRMArrestBody") b:SetTextColor(UI.text)
        b:SetTall(tall or 34)
        b:SetContentAlignment(5)
        b.Paint = function(self, w, h)
            local c = color or UI.card2
            if self:IsHovered() then c = Color(math.min(c.r + 18, 255), math.min(c.g + 18, 255), math.min(c.b + 18, 255), c.a) end
            draw.RoundedBox(6, 0, 0, w, h, c)
        end
        return b
    end

    local function sendAction(action, id, extra)
        net.Start("GRM_Arrest_AdminAction")
            net.WriteString(action or "")
            net.WriteString(id or "")
            if extra then extra() end
        net.SendToServer()
    end

    local function sectionTitle(parent, title, subtitle)
        local p = vgui.Create("DPanel", parent)
        p:Dock(TOP) p:SetTall(48) p:DockMargin(0, 0, 0, 8) p:SetPaintBackground(false)
        local t = label(p, title, "GRMArrestHeading", UI.text) t:SetPos(0, 0) t:SetSize(600, 24)
        local s = label(p, subtitle or "", "GRMArrestSmall", UI.dim) s:SetPos(0, 25) s:SetSize(700, 20)
        return p
    end

    local function card(parent, height)
        local p = vgui.Create("DPanel", parent)
        p:Dock(TOP) p:SetTall(height) p:DockMargin(0, 0, 0, 10)
        p:SetPaintBackground(false)
        p.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, UI.card)
            draw.RoundedBox(8, 0, 0, 4, h, UI.accent)
        end
        return p
    end

    local function openGroupEditor(gid, source)
        local ed = table.Copy(source or {})
        ed.bodygroups = istable(ed.bodygroups) and ed.bodygroups or {}
        local w = vgui.Create("DFrame")
        GRM.UI.Track("arrest_group_editor", w)
        w:SetSize(920, 650) w:Center() w:MakePopup() w:SetTitle("") w:ShowCloseButton(false)
        w:SetDeleteOnClose(true)
        w.Paint = function(_, pw, ph)
            draw.RoundedBox(10, 0, 0, pw, ph, UI.bg)
            draw.RoundedBoxEx(10, 0, 0, pw, 62, UI.header, true, true, false, false)
            draw.SimpleText("ВНЕШНОСТЬ ГРУППЫ", "GRMArrestSmall", 22, 17, UI.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(tostring(ed.name or gid), "GRMArrestTitle", 22, 42, UI.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        local close = button(w, "×", UI.red, 30) close:SetPos(870, 16) close:SetSize(32, 30)
        close.DoClick = function() w:Close() end

        local model = vgui.Create("DTextEntry", w) model:SetPos(24, 92) model:SetSize(560, 34) model:SetFont("GRMArrestBody") model:SetText(ed.model or "")
        model:SetPlaceholderText("Путь к модели, например models/grworkers/grworker.mdl")
        model.Paint = function(self, pw, ph) draw.RoundedBox(5, 0, 0, pw, ph, UI.card2); self:DrawTextEntryText(UI.text, UI.accent, UI.text) end
        local load = button(w, "Обновить превью", UI.accent, 34) load:SetPos(594, 92) load:SetSize(160, 34)
        local preview = vgui.Create("DModelPanel", w) preview:SetPos(640, 150) preview:SetSize(230, 330) preview:SetFOV(42) preview.LayoutEntity = function() end
        preview.PaintOver = function(_, pw, ph) draw.RoundedBox(6, 0, 0, pw, ph, Color(0, 0, 0, 18)) end
        local previewHint = label(w, "ПРЕДПРОСМОТР", "GRMArrestSmall", UI.dim) previewHint:SetPos(640, 490) previewHint:SetSize(230, 20) previewHint:SetContentAlignment(5)

        local body = vgui.Create("DScrollPanel", w) body:SetPos(24, 145) body:SetSize(570, 330)
        local bodyTitle = label(w, "Параметры внешности", "GRMArrestHeading", UI.text) bodyTitle:SetPos(24, 126) bodyTitle:SetSize(400, 24)
        local skin = vgui.Create("DNumSlider", w) skin:SetPos(24, 500) skin:SetSize(570, 32) skin:SetText("Skin") skin:SetMin(0) skin:SetMax(16) skin:SetDecimals(0) skin:SetValue(ed.skin or 0)
        if IsValid(skin.Label) then skin.Label:SetFont("GRMArrestBody") skin.Label:SetTextColor(UI.text) end
        local function applyAppearance(ent)
            if not IsValid(ent) then return end
            local maxSkin = math.max(0, (ent:SkinCount() or 1) - 1)
            local selectedSkin = math.Clamp(math.floor(tonumber(ed.skin) or 0), 0, maxSkin)
            ent:SetSkin(selectedSkin)
            for group, value in pairs(ed.bodygroups or {}) do
                local gi, vi = tonumber(group), tonumber(value)
                if gi and vi then ent:SetBodygroup(gi, vi) end
            end
        end
        skin.OnValueChanged = function(_, value)
            ed.skin = math.floor(tonumber(value) or 0)
            applyAppearance(preview:GetEntity())
        end
        local function rebuild()
            body:Clear()
            local ent = IsValid(preview:GetEntity()) and preview:GetEntity() or nil
            if not IsValid(ent) then
                local hint = label(body, "Укажите корректную модель и нажмите «Обновить превью».", "GRMArrestBody", UI.dim)
                hint:Dock(TOP) hint:SetTall(50)
                return
            end
            local count = 0
            for i = 0, (ent:GetNumBodyGroups() or 0) - 1 do
                local variants = ent:GetBodygroupCount(i) or 1
                if variants > 1 then
                    count = count + 1
                    local row = vgui.Create("DPanel", body) row:Dock(TOP) row:SetTall(48) row:DockMargin(0, 0, 8, 6) row:SetPaintBackground(false)
                    local name = ent:GetBodygroupName(i) or ("Группа " .. i)
                    local title = label(row, name, "GRMArrestBody", UI.text) title:Dock(LEFT) title:SetWide(210) title:SetContentAlignment(4)
                    local combo = vgui.Create("DComboBox", row) combo:Dock(FILL) combo:SetTall(34) combo:SetValue("Вариант " .. tostring(ed.bodygroups[i] or 0))
                    for value = 0, variants - 1 do combo:AddChoice("Вариант " .. value, value) end
                    combo.OnSelect = function(_, _, _, value)
                        -- DComboBox передаёт выбранные данные четвёртым
                        -- аргументом. Третий аргумент — отображаемый текст.
                        ed.bodygroups[i] = tonumber(value) or 0
                        applyAppearance(preview:GetEntity())
                    end
                end
            end
            if count == 0 then
                local hint = label(body, "У этой модели нет настраиваемых bodygroups.", "GRMArrestBody", UI.dim)
                hint:Dock(TOP) hint:SetTall(40)
            end
        end
        local function refreshPreview()
            local path = string.Trim(model:GetValue() or "")
            if util.IsValidModel(path) then
                preview:SetModel(path)
                applyAppearance(preview:GetEntity())
                rebuild()
            end
        end
        load.DoClick = refreshPreview
        if util.IsValidModel(model:GetValue()) then
            preview:SetModel(model:GetValue())
            applyAppearance(preview:GetEntity())
            rebuild()
        else
            rebuild()
        end

        local save = button(w, "СОХРАНИТЬ ВНЕШНОСТЬ", UI.green, 40) save:SetPos(640, 550) save:SetSize(230, 40)
        save.DoClick = function()
            sendAction("set_group_data", gid, function()
                net.WriteTable({ model = model:GetValue(), skin = skin:GetValue(), bodygroups = ed.bodygroups })
            end)
            w:Close()
        end
    end

    net.Receive("GRM_Arrest_AdminData", function()
        local data = net.ReadTable() or {}
        local f = vgui.Create("DFrame")
        GRM.UI.Track("arrest_admin", f)
        f:SetSize(1120, 760) f:Center() f:MakePopup() f:SetTitle("") f:ShowCloseButton(false) f:SetDeleteOnClose(true)
        f.Paint = function(_, pw, ph)
            draw.RoundedBox(10, 0, 0, pw, ph, UI.bg)
            draw.RoundedBoxEx(10, 0, 0, pw, 66, UI.header, true, true, false, false)
            draw.SimpleText("GRM  /  СИСТЕМА АРЕСТА", "GRMArrestSmall", 24, 19, UI.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText("Камеры, группы и точки содержания", "GRMArrestTitle", 24, 45, UI.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        local close = button(f, "×", UI.red, 32) close:SetPos(1072, 17) close:SetSize(32, 32) close.DoClick = function() f:Close() end

        local side = vgui.Create("DPanel", f) side:SetPos(0, 66) side:SetSize(245, 694) side:SetPaintBackground(false)
        side.Paint = function(_, pw, ph)
            draw.RoundedBoxEx(10, 0, 0, pw, ph, UI.sidebar, false, false, true, false)
            draw.RoundedBox(0, pw - 1, 0, 1, ph, UI.line)
        end
        local sideTitle = label(side, "УПРАВЛЕНИЕ", "GRMArrestSmall", UI.dim) sideTitle:SetPos(24, 28) sideTitle:SetSize(190, 20)
        local help = label(side, "Настройте место камеры, точку телепорта и внешний вид каждой категории арестованных.", "GRMArrestBody", UI.text) help:SetPos(24, 58) help:SetSize(195, 100)
        local stat = label(side, string.format("ГРУППЫ  %d\nКАМЕРЫ  %d\nТОЧКИ    %d", table.Count(data.groups or {}), #(data.cameras or {}), #(data.spawns or {})), "GRMArrestBody", UI.dim) stat:SetPos(24, 190) stat:SetSize(190, 90)
        local hint = label(side, "Добавление происходит в точке прицела или под ногами администратора. После сохранения меню обновится автоматически.", "GRMArrestSmall", UI.dim) hint:SetPos(24, 540) hint:SetSize(195, 90)

        local content = vgui.Create("DScrollPanel", f) content:SetPos(269, 86) content:SetSize(825, 650)
        local canvas = content:GetCanvas()
        sectionTitle(canvas, "Быстрые действия", "Создайте объекты на карте, затем свяжите камеру с точкой содержания.")
        local actionBar = vgui.Create("DPanel", canvas) actionBar:Dock(TOP) actionBar:SetTall(46) actionBar:DockMargin(0, 0, 0, 18) actionBar:SetPaintBackground(false)
        local addCam = button(actionBar, "+  Камера в прицеле", UI.accent, 40) addCam:Dock(LEFT) addCam:SetWide(245) addCam.DoClick = function() sendAction("add_camera", "") end
        local addSpawn = button(actionBar, "+  Точка арестованного", UI.green, 40) addSpawn:Dock(LEFT) addSpawn:DockMargin(10, 0, 0, 0) addSpawn:SetWide(245) addSpawn.DoClick = function() sendAction("add_spawn", "") end

        sectionTitle(canvas, "Группы арестованных", "Модель, skin и bodygroups сохраняются в конфигурации и применяются при аресте.")
        for gid, g in pairs(data.groups or {}) do
            local p = card(canvas, 86)
            local name = label(p, tostring(g.name or gid), "GRMArrestHeading", UI.text) name:SetPos(20, 13) name:SetSize(350, 24)
            local id = label(p, tostring(gid) .. "   •   " .. tostring(g.model or "модель не задана"), "GRMArrestSmall", UI.dim) id:SetPos(20, 42) id:SetSize(510, 22)
            local edit = button(p, "Настроить внешность", UI.accent, 36) edit:SetPos(585, 22) edit:SetSize(200, 36) edit.DoClick = function() openGroupEditor(gid, g) end
        end

        sectionTitle(canvas, "Камеры и точки содержания", "Камера определяет категорию, точка — место появления арестованного.")
        for _, cam in ipairs(data.cameras or {}) do
            local p = card(canvas, 150)
            local title = label(p, "КАМЕРА  " .. tostring(cam.id), "GRMArrestHeading", UI.text) title:SetPos(20, 12) title:SetSize(300, 24)
            local meta = label(p, "Группа: " .. tostring(cam.group or "criminals") .. "   •   Точка: " .. tostring(cam.spawnID or "не назначена"), "GRMArrestSmall", UI.dim) meta:SetPos(20, 40) meta:SetSize(470, 22)
            local combo = vgui.Create("DComboBox", p) combo:SetPos(505, 12) combo:SetSize(280, 32) combo:SetValue("Выбрать группу")
            for gid, g in pairs(data.groups or {}) do combo:AddChoice(tostring(g.name or gid) .. "  [" .. gid .. "]", gid) end
            local setGroup = button(p, "Назначить группу", UI.accent, 30) setGroup:SetPos(505, 52) setGroup:SetSize(135, 30)
            setGroup.DoClick = function() local gid = combo:GetOptionData(combo:GetSelectedID()) or cam.group or "criminals"; sendAction("set_camera_group", cam.id, function() net.WriteString(gid) end) end
            local setSpawn = button(p, "Привязать точку", UI.green, 30) setSpawn:SetPos(650, 52) setSpawn:SetSize(135, 30)
            setSpawn.DoClick = function()
                local menu = DermaMenu()
                for index, sp in ipairs(data.spawns or {}) do
                    local caption = string.format("Точка %d  •  %s  [%s]", index, tostring(sp.name or "Точка ареста"), tostring(sp.id or "—"))
                    menu:AddOption(caption, function() sendAction("assign_camera_spawn", cam.id, function() net.WriteString(sp.id) end) end)
                end
                menu:AddOption("Снять привязку", function() sendAction("assign_camera_spawn", cam.id, function() net.WriteString("") end) end)
                menu:Open()
            end
            local remove = button(p, "Удалить камеру", UI.red, 30) remove:SetPos(505, 94) remove:SetSize(280, 30)
            remove.DoClick = function()
                Derma_Query("Удалить камеру «" .. tostring(cam.id) .. "»?", "Подтверждение удаления", "Удалить", function() sendAction("delete_camera", cam.id) end, "Отмена")
            end
        end
        if #(data.cameras or {}) == 0 then
            local empty = card(canvas, 70) local txt = label(empty, "Камеры ещё не созданы. Нажмите «Камера в прицеле», стоя у нужной двери.", "GRMArrestBody", UI.dim) txt:SetPos(20, 22) txt:SetSize(760, 28)
        end

        sectionTitle(canvas, "Точки арестованных", "Удаление точки автоматически снимает её привязку со всех камер.")
        if #(data.spawns or {}) == 0 then
            local empty = card(canvas, 70) local txt = label(empty, "Точки ещё не созданы. Нажмите «Точка арестованного».", "GRMArrestBody", UI.dim) txt:SetPos(20, 22) txt:SetSize(760, 28)
        else
            for index, sp in ipairs(data.spawns or {}) do
                local p = card(canvas, 82)
                local title = label(p, "ТОЧКА " .. tostring(index) .. "  •  " .. tostring(sp.id), "GRMArrestHeading", UI.text) title:SetPos(20, 13) title:SetSize(450, 24)
                local meta = label(p, tostring(sp.name or ("Точка ареста " .. tostring(index))), "GRMArrestSmall", UI.dim) meta:SetPos(20, 43) meta:SetSize(450, 20)
                local remove = button(p, "Удалить точку", UI.red, 34) remove:SetPos(585, 22) remove:SetSize(200, 34)
                remove.DoClick = function()
                    Derma_Query("Удалить точку «" .. tostring(sp.id) .. "»? Привязка камер будет снята.", "Подтверждение удаления", "Удалить", function() sendAction("delete_spawn", sp.id) end, "Отмена")
                end
            end
        end

        sectionTitle(canvas, "Новая группа", "Создайте собственную категорию, затем настройте её внешний вид.")
        local form = card(canvas, 128)
        local name = vgui.Create("DTextEntry", form) name:SetPos(20, 18) name:SetSize(235, 34) name:SetPlaceholderText("Название, например Политические")
        local model = vgui.Create("DTextEntry", form) model:SetPos(270, 18) model:SetSize(280, 34) model:SetPlaceholderText("models/.../model.mdl")
        local gid = vgui.Create("DTextEntry", form) gid:SetPos(565, 18) gid:SetSize(220, 34) gid:SetPlaceholderText("ID: political")
        local create = button(form, "Создать / сохранить группу", UI.orange, 38) create:SetPos(20, 70) create:SetSize(765, 38)
        create.DoClick = function() sendAction("set_group", gid:GetValue(), function() net.WriteString(name:GetValue()) net.WriteString(model:GetValue()) end) end
    end)

    hook.Add("HUDPaint", "GRM_Arrest_Label", function()
        local lp = LocalPlayer()
        if not IsValid(lp) then return end
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) and p:GetNWBool("GRM_Arrested", false) and (p == lp or lp:GetPos():DistToSqr(p:GetPos()) < 600 * 600) then
                local sp = (p:GetPos() + Vector(0, 0, 82)):ToScreen()
                if sp.visible then
                    draw.RoundedBox(5, sp.x - 120, sp.y - 26, 240, 30, Color(13, 18, 27, 220))
                    draw.SimpleText("АРЕСТОВАННЫЙ  •  " .. p:GetNWString("GRM_ArrestGroupName", ""), "GRMArrestSmall", sp.x, sp.y - 11, UI.orange, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end
        end
    end)
end

print("[GRM Arrest] v" .. A.Version .. " loaded")
