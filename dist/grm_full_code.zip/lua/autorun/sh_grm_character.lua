--[[--------------------------------------------------------------------
    GRM Identity Core v1.7.0 (Код 72) — Персонажи, RP-имена, регистрация
    v1.7.0: reentrancy/action guards; singleton signature survives rebuild.
    Ядро + точки расширения (патчи-провайдеры):

      - При КАЖДОМ входе игрок встречает меню персонажа:
        нет персонажа → создание (RP-имя + внешность с живым превью);
        есть персонаж → продолжить / изменить имя / изменить внешность.
      - RP-имя хранится на сервере (grm_characters.json) и рассылается
        клиентам (NWString GRM_RPName). Команда /name Имя Фамилия.
      - Внешность (модель/skin/bodygroups) валидируется против списков
        фракционной системы (DefaultModels → фракция/роль/отдел) и
        применяется через FactionsExt ApplyModelSettings — аппарат
        строгого удержания внешности (ModelCheck) конфликтов не даёт.
      - PROVIDER API (патчи): GRM.Char.RegisterProvider(id, def) —
        меню персонажа собирается из провайдеров; фракционный гардероб
        уже встроен как провайдер "faction". Любой будущий модуль
        (гардероб-энтити, работы, лицензии) добавляет свои секции без
        правок ядра.
      - Синхронизация со спавн-поинтами: при первичной регистрации члена
        фракции игрок переносится на фракционную точку (GetSpawnPointForPlayer).
    Данные: data/grm_characters.json  (ключи sid64 — чтение ТОЛЬКО jsonT c
    третьим аргументом, урок находки 65).
----------------------------------------------------------------------]]

if SERVER then AddCSLuaFile() end

GRM = GRM or {}
GRM.Char = GRM.Char or {}
local CH = GRM.Char

CH.Version    = "1.7.0"
CH.NameMin    = 3     -- минимальная длина RP-имени
CH.NameMax    = 48
    CH.DataFile   = "grm_characters.json"
CH.MaxSlots    = 3
CH.PendingSelection = CH.PendingSelection or {}
CH.PendingMandatory = CH.PendingMandatory or {}

local NET_OPEN    = "GRM_Char_Open"
local NET_SAVE    = "GRM_Char_Save"
local NET_REQUEST = "GRM_Char_Request"
local NET_CLOSE   = "GRM_Char_Close"
local NET_CANCEL   = "GRM_Char_Cancel"

-- ------------------------------------------------------------
-- SHARED: валидация имени и нормализация внешности
-- ------------------------------------------------------------
function CH.ValidateName(raw)
    local s = string.Trim(tostring(raw or ""))
    s = string.gsub(s, "%s+", " ")
    if #s < CH.NameMin then return nil, "Имя короче " .. CH.NameMin .. " символов" end
    if #s > CH.NameMax then s = string.sub(s, 1, CH.NameMax) end
    return s
end

function CH.GetName(plyOrSid64)
    if IsValid(plyOrSid64) and plyOrSid64:IsPlayer() then
        return plyOrSid64:GetNWString("GRM_RPName", "")
    end
    return ""
end

function CH.GetActiveID(ply)
    if IsValid(ply) and ply:IsPlayer() then return ply:GetNWString("GRM_CharacterID", "") end
    return ""
end

function CH.GetActiveKey(ply)
    if GRM.Identity and GRM.Identity.CharacterKey then
        return GRM.Identity.CharacterKey(ply)
    end
    if IsValid(ply) and ply:IsPlayer() then
        local key = ply:GetNWString("GRM_CharacterKey", "")
        if key ~= "" then return key end
        return ply:SteamID64()
    end
    return tostring(ply or "")
end

function CH.MakeCharacterID(ply)
    local sid = IsValid(ply) and ply:SteamID64() or "0"
    return sid .. ":char1"
end

-- ------------------------------------------------------------
-- Провайдер-патчи (shared-регистрация, исполнение на сервере)
-- def = { Order=100, Title=function(ply).., Outfits=function(ply) -> {entry,...} }
-- entry = { path=..., skin=0, bodygroups={} }
-- ------------------------------------------------------------
CH.Providers = CH.Providers or {}
function CH.RegisterProvider(id, def)
    if not isstring(id) or not istable(def) then return end
    if not isfunction(def.Outfits) then return end
    CH.Providers[id] = def
    table.sort(CH.ProvidersSort or {}, function() end) -- no-op guard
end

-- ============================================================
-- СЕРВЕР
-- ============================================================
if SERVER then
    util.AddNetworkString(NET_OPEN)
    util.AddNetworkString(NET_SAVE)
    util.AddNetworkString(NET_REQUEST)
    util.AddNetworkString(NET_CLOSE)
    util.AddNetworkString(NET_CANCEL)

    local function jsonT(txt)
        local ok, t = pcall(util.JSONToTable, txt, false, true)
        return (ok and istable(t)) and t or nil
    end

    local function loadChars()
        CH.Data = CH.Data or {}
        if not file.Exists(CH.DataFile, "DATA") then return CH.Data end
        local t = jsonT(file.Read(CH.DataFile, "DATA") or "")
        if istable(t) then CH.Data = t end
        return CH.Data
    end

    local function saveChars(reason)
        local ok, txt = pcall(util.TableToJSON, CH.Data or {}, true)
        if ok and txt then
            file.Write(CH.DataFile, txt)
            local back = readbackCheck()
            if not back then
                ErrorNoHalt("[GRM Char] SAVE FAIL (" .. tostring(reason) .. ")\n")
            end
        end
    end
    function readbackCheck()
        local t = file.Read(CH.DataFile, "DATA")
        return t ~= nil and #t > 2
    end

    loadChars()

    local function sid64(ply) return IsValid(ply) and ply:SteamID64() or "" end
    local function clampSlot(n)
        n = math.floor(tonumber(n) or 1)
        if n < 1 then return 1 end
        if n > (CH.MaxSlots or 3) then return CH.MaxSlots or 3 end
        return n
    end
    local function slotID(n) return "char" .. tostring(clampSlot(n)) end

    local function normalizePlayerData(ply)
        if not IsValid(ply) then return nil end
        local sid = sid64(ply)
        CH.Data[sid] = istable(CH.Data[sid]) and CH.Data[sid] or {}
        local rec = CH.Data[sid]

        -- Legacy migration: old format stored one character directly at CH.Data[sid].
        if not istable(rec.slots) then
            local old = table.Copy(rec)
            rec = { active = "char1", slots = {} }
            if old.name or old.model or old.id then
                old.id = "char1"
                old.key = sid .. ":char1"
                rec.slots.char1 = old
            end
            CH.Data[sid] = rec
            saveChars("migrate-multichar")
        end

        rec.active = tostring(rec.active or "char1")
        if not rec.active:match("^char[123]$") then rec.active = "char1" end
        rec.slots = istable(rec.slots) and rec.slots or {}
        return rec
    end

    local function activeSlot(ply)
        local rec = normalizePlayerData(ply)
        return rec and rec.active or "char1"
    end

    local function activeChar(ply)
        local rec = normalizePlayerData(ply)
        if not rec then return nil end
        local c = rec.slots[rec.active]
        if istable(c) then
            c.id = rec.active
            c.key = sid64(ply) .. ":" .. rec.active
            return c
        end
        return nil
    end

    local function hasCharacter(ply, slot)
        local rec = normalizePlayerData(ply)
        slot = tostring(slot or (rec and rec.active) or "char1")
        return rec and rec.slots and istable(rec.slots[slot]) and tostring(rec.slots[slot].name or "") ~= ""
    end

    local function setCharacterLock(ply, locked, mandatory)
        if not IsValid(ply) then return end
        local sid = ply:SteamID64()
        CH.PendingSelection[sid] = locked == true or nil
        CH.PendingMandatory[sid] = locked == true and mandatory == true or nil
        if ply.SetNWBool then
            ply:SetNWBool("GRM_CharacterPending", locked == true)
            ply:SetNWBool("GRM_CharacterMandatory", locked == true and mandatory == true)
        end
        if ply.Freeze then ply:Freeze(locked == true) end
    end

    local function ensureChar(ply, slot)
        local rec = normalizePlayerData(ply)
        if not rec then return nil end
        slot = tostring(slot or rec.active or "char1")
        if not slot:match("^char[123]$") then slot = "char1" end
        rec.active = slot
        rec.slots[slot] = istable(rec.slots[slot]) and rec.slots[slot] or {}
        local c = rec.slots[slot]
        c.id = slot
        c.key = sid64(ply) .. ":" .. slot
        ply:SetNWString("GRM_CharacterID", c.id)
        ply:SetNWString("GRM_CharacterKey", c.key)
        return c
    end
    CH.Ensure = ensureChar

    function CH.Get(ply) return activeChar(ply) end
    function CH.GetActiveID(ply) return activeSlot(ply) end
    function CH.GetActiveKey(ply) return sid64(ply) .. ":" .. activeSlot(ply) end

    local function applyActiveCharacter(ply)
        local c = CH.Get(ply)
        -- Сбрасываем желаемую модель прошлого персонажа до проверки нового.
        ply.FactionsExt_DesiredModelData = nil
        if istable(c) then
            ply:SetNWString("GRM_CharacterID", tostring(c.id or activeSlot(ply)))
            ply:SetNWString("GRM_CharacterKey", tostring(c.key or CH.GetActiveKey(ply)))
            ply:SetNWString("GRM_RPName", tostring(c.name or ""))
            local applied = false
            if isstring(c.model) and c.model ~= "" then
                applied = CH.ApplyAppearance(ply, { path = c.model, skin = c.skin, bodygroups = c.bodygroups }) == true
            end
            -- Старый/чужой faction-модельный путь не должен оставаться на новом
            -- персонаже: берём первую разрешённую модель текущей роли/гражданина.
            if not applied and _G.GetModelsForPlayer then
                local allowed = _G.GetModelsForPlayer(ply) or {}
                local fallback = allowed[1]
                if istable(fallback) and isstring(fallback.path) then
                    c.model = fallback.path
                    c.skin = tonumber(fallback.skin) or 0
                    c.bodygroups = table.Copy(fallback.bodygroups or {})
                    CH.ApplyAppearance(ply, fallback)
                    saveChars("model-fallback")
                end
            end
        else
            ply:SetNWString("GRM_CharacterID", activeSlot(ply))
            ply:SetNWString("GRM_CharacterKey", CH.GetActiveKey(ply))
            ply:SetNWString("GRM_RPName", "")
        end
    end

    function CH.SetActiveSlot(ply, slot, forceSpawn)
        local oldKey = CH.GetActiveKey(ply)
        local rec = normalizePlayerData(ply)
        if not rec then return false end
        slot = tostring(slot or "char1")
        if not slot:match("^char[123]$") then return false end
        rec.active = slot
        saveChars("select-slot")
        applyActiveCharacter(ply)
        setCharacterLock(ply, not hasCharacter(ply, slot), true)
        if GRM.Inventory and GRM.Inventory.SyncToClient then
            timer.Simple(0.05, function() if IsValid(ply) then GRM.Inventory.SyncToClient(ply) end end)
        end
        local newKey = CH.GetActiveKey(ply)
        hook.Run("GRM_CharacterChanged", ply, oldKey, newKey)
        local shouldSpawn = forceSpawn == true or oldKey ~= newKey
        if shouldSpawn then
            timer.Simple(0, function()
                if not IsValid(ply) or not hasCharacter(ply, slot) then return end
                if ply.Alive and ply:Alive() and ply.Spawn then ply:Spawn() end
            end)
        end
        return true
    end

    function CH.SetName(ply, name, slot)
        name = CH.ValidateName(name)
        if not name then return false, "Некорректное имя" end
        local c = ensureChar(ply, slot)
        c.name = name
        c.updated = os.time()
        ply:SetNWString("GRM_RPName", name)
        saveChars("setname")
        return true
    end

    local function isAllowedModel(ply, path)
        if _G.IsModelAllowedForPlayer then
            return _G.IsModelAllowedForPlayer(ply, path)
        end
        return true
    end

    function CH.ApplyAppearance(ply, entry)
        if IsValid(ply) and ply:GetNWBool("GRM_Arrested", false) then return false, "Внешность заблокирована во время ареста" end
        if not IsValid(ply) or not istable(entry) or not isstring(entry.path) then return false end
        if not isAllowedModel(ply, entry.path) then return false, "Модель не разрешена вашей фракцией/ролью" end

        if _G.ApplyModelSettings then
            _G.ApplyModelSettings(ply, { path = entry.path, skin = tonumber(entry.skin) or 0, bodygroups = entry.bodygroups or {} })
        else
            ply:SetModel(entry.path)
            ply:SetSkin(tonumber(entry.skin) or 0)
            local count = ply:GetNumBodyGroups() or 0
            for i = 0, count - 1 do ply:SetBodygroup(i, 0) end
            for g, v in pairs(entry.bodygroups or {}) do
                ply:SetBodygroup(tonumber(g) or 0, tonumber(v) or 0)
            end
        end
        -- синхронизация со строгим удержанием FactionsExt: эта запись побеждает в ModelCheck
        ply.FactionsExt_DesiredModelData = { path = entry.path, skin = tonumber(entry.skin) or 0, bodygroups = table.Copy(entry.bodygroups or {}) }

        local c = ensureChar(ply)
        c.model = entry.path
        c.skin = tonumber(entry.skin) or 0
        c.bodygroups = table.Copy(entry.bodygroups or {})
        c.updated = os.time()
        saveChars("appearance")
        return true
    end

    local function factionMembership(ply, characterKey)
        characterKey = tostring(characterKey or "")
        for name,f in pairs(Factions or {}) do
            if istable(f) and istable(f.Members) then
                local member
                if characterKey ~= "" then member = f.Members[characterKey]
                else member = GRM.Identity and GRM.Identity.FactionMember and GRM.Identity.FactionMember(f,ply) end
                if istable(member) then return name,member,f end
            end
        end
        return nil
    end

    local function modelsForContext(ply, context)
        if not istable(context) or not context.preview then
            return _G.GetModelsForPlayer and (_G.GetModelsForPlayer(ply) or {}) or {}
        end
        if context.factionName and context.faction then
            if context.onDuty == false then return istable(DefaultModels) and DefaultModels or {} end
            local f, member = context.faction, context.member or {}
            local role, department = member.Role, member.Department
            if role and istable(f.RoleModels) and istable(f.RoleModels[role]) and #f.RoleModels[role] > 0 then return f.RoleModels[role] end
            if department and istable(f.DepartmentModels) and istable(f.DepartmentModels[department]) and #f.DepartmentModels[department] > 0 then return f.DepartmentModels[department] end
            if istable(f.Models) and #f.Models > 0 then return f.Models end
        end
        return istable(DefaultModels) and DefaultModels or {}
    end

    -- провайдеры по умолчанию -----------------------------------
    CH.RegisterProvider("civilian", {
        Order = 10,
        Title = function(ply) return "Гражданская внешность" end,
        Outfits = function(ply)
            local out = {}
            if istable(DefaultModels) then
                for _, e in ipairs(DefaultModels) do
                    if istable(e) and isstring(e.path) then out[#out + 1] = { path = e.path, skin = tonumber(e.skin) or 0, bodygroups = table.Copy(istable(e.bodygroups) and e.bodygroups or {}) } end
                end
            end
            return out
        end,
    })

    CH.RegisterProvider("faction", {
        Order = 20,
        Title = function(ply, context)
            local n,m = context and context.factionName, context and context.member
            if not n then n,m=factionMembership(ply) end
            if not n then return nil end
            local onDuty = context and context.onDuty
            if onDuty == nil then onDuty = GRM.FactionDuty and GRM.FactionDuty.IsOnDuty and GRM.FactionDuty.IsOnDuty(ply) end
            return "Фракция: "..n..(m.Role and (" — "..tostring(m.Role)) or "").." • "..(onDuty and "НА СЛУЖБЕ" or "ВНЕ СЛУЖБЫ")
        end,
        Outfits = function(ply, context)
            local factionName = context and context.factionName or factionMembership(ply)
            if not factionName then return {} end
            local out = {}
            for _, e in ipairs(modelsForContext(ply, context) or {}) do
                if istable(e) and isstring(e.path) then out[#out + 1] = { path = e.path, skin = tonumber(e.skin) or 0, bodygroups = table.Copy(istable(e.bodygroups) and e.bodygroups or {}) } end
            end
            return out
        end,
    })

    -- полезная нагрузка меню ------------------------------------
    -- opts: { wardrobe=bool, title=str, allowCivilian/allowFaction/
    --         allowSkin/allowBodygroups = bool|nil, ent=Entity }
    function CH.BuildPayload(ply, opts)
        opts = istable(opts) and opts or {}
        local rec = normalizePlayerData(ply) or { active = "char1", slots = {} }
        local previewSlot = tostring(opts.previewSlot or rec.active or "char1")
        if not previewSlot:match("^char[123]$") then previewSlot = rec.active or "char1" end
        local previewKey = sid64(ply) .. ":" .. previewSlot
        local previewChar = istable(rec.slots[previewSlot]) and rec.slots[previewSlot] or nil
        if previewChar then previewChar.id = previewSlot; previewChar.key = previewKey end
        local factionName,member,faction=factionMembership(ply, previewKey)
        local hasFaction=factionName~=nil
        local onDuty = false
        if hasFaction then
            local state = GRM.FactionDuty and GRM.FactionDuty.State and GRM.FactionDuty.State[previewKey]
            onDuty = state == nil or state == true
        end
        local context = { preview = previewSlot ~= rec.active, slot = previewSlot, characterKey = previewKey,
            character = previewChar, factionName = factionName, member = member, faction = faction, onDuty = onDuty }
        local sections = {}
        local ids = {}
        for id in pairs(CH.Providers) do ids[#ids + 1] = id end
        table.sort(ids, function(a, b)
            local oa = tonumber(CH.Providers[a].Order) or 100
            local ob = tonumber(CH.Providers[b].Order) or 100
            if oa == ob then return a < b end
            return oa < ob
        end)
        for _, id in ipairs(ids) do
            local skip = false
            -- Гражданская и фракционная внешность взаимоисключающие:
            -- персонаж фракции не видит civilian-пул, гражданский не видит faction-пул.
            if id == "civilian" and hasFaction then skip = true end
            if id == "faction" and not hasFaction then skip = true end
            if opts.wardrobe and id == "civilian" and opts.allowCivilian == false then skip = true end
            if opts.wardrobe and id == "faction" and opts.allowFaction == false then skip = true end
            if not skip then
                local def = CH.Providers[id]
                local okT, title = pcall(def.Title or function() return id end, ply, context)
                if okT and title then
                    local okO, outfits = pcall(def.Outfits, ply, context)
                    if okO and istable(outfits) and #outfits > 0 then
                        sections[#sections + 1] = { id = id, title = tostring(title), outfits = outfits }
                    end
                end
            end
        end
        local allOutfits,seenOutfits = {},{}
        for _,section in ipairs(sections) do
            for _,outfit in ipairs(section.outfits or {}) do
                local sig=string.lower(tostring(outfit.path or "")).."|"..tostring(tonumber(outfit.skin) or 0).."|"..tostring(util.TableToJSON(outfit.bodygroups or {}) or "")
                if not seenOutfits[sig] then
                    seenOutfits[sig]=true; local copy=table.Copy(outfit); copy.provider=section.id; copy.providerTitle=section.title; allOutfits[#allOutfits+1]=copy
                end
            end
        end

        local slots = {}
        for i = 1, CH.MaxSlots do
            local id = slotID(i)
            local c = rec.slots[id]
            local slotFaction, slotMember = factionMembership(ply, sid64(ply) .. ":" .. id)
            slots[#slots + 1] = { id = id, index = i, exists = istable(c), name = istable(c) and tostring(c.name or "") or "",
                model = istable(c) and tostring(c.model or "") or "", skin = istable(c) and tonumber(c.skin) or 0,
                bodygroups = istable(c) and table.Copy(c.bodygroups or {}) or {}, factionName = slotFaction or "",
                factionRole = slotMember and tostring(slotMember.Role or "") or "",
                factionDepartment = slotMember and tostring(slotMember.Department or "") or "" }
        end
        return {
            char = previewChar,
            slots = slots,
            activeSlot = rec.active or "char1",
            previewSlot = previewSlot,
            characterID = previewSlot,
            characterKey = previewKey,
            identityNote = "Предпросмотр CharacterKey: " .. previewKey .. ". Активный: " .. CH.GetActiveKey(ply) .. ".",
            sections = sections, -- legacy payload compatibility
            outfits = allOutfits,
            nameMin = CH.NameMin, nameMax = CH.NameMax,
            wardrobe = opts.wardrobe == true or nil,
            wardrobeTitle = opts.title,
            wardrobeEnt = IsValid(opts.ent) and opts.ent:EntIndex() or nil,
            allowSkin = opts.allowSkin, allowBodygroups = opts.allowBodygroups,
            isAdmin = ply:IsSuperAdmin() or nil,
            pending = CH.PendingSelection[sid64(ply)] == true,
            mandatory = CH.PendingMandatory[sid64(ply)] == true,
            factionName = factionName or "",
            factionRole = member and tostring(member.Role or "") or "",
            factionDepartment = member and tostring(member.Department or "") or "",
            onDuty = onDuty,
        }
    end

    local function sendMenu(ply, previewSlot)
        if not IsValid(ply) then return end
        net.Start(NET_OPEN)
            net.WriteTable(CH.BuildPayload(ply, { previewSlot = previewSlot }))
        net.Send(ply)
    end
    CH.OpenMenu = sendMenu

    local function closeMenu(ply)
        if not IsValid(ply) then return end
        net.Start(NET_CLOSE)
        net.Send(ply)
    end

    -- вход: меню при КАЖДОМ заходе -------------------------------
    hook.Add("PlayerInitialSpawn", "GRM_Char_OnJoin", function(ply)
        timer.Simple(1.5, function() if IsValid(ply) then sendMenu(ply) end end)
        timer.Simple(0.2, function()
            if not IsValid(ply) then return end
            normalizePlayerData(ply)
            -- При каждом входе игрок обязан явно подтвердить персонажа.
            setCharacterLock(ply, true, true)
        end)
        timer.Simple(2.2, function()
            if not IsValid(ply) then return end
            normalizePlayerData(ply)
            applyActiveCharacter(ply)
            setCharacterLock(ply, true, true)
        end)
    end)

    hook.Add("PlayerSpawn", "GRM_Char_BlockUnselectedSpawn", function(ply)
        timer.Simple(0, function()
            if not IsValid(ply) then return end
            if CH.PendingSelection[ply:SteamID64()] then
                setCharacterLock(ply, true, CH.PendingMandatory[ply:SteamID64()] == true)
                -- Меню уже открывается одним таймером PlayerInitialSpawn.
                -- Не отправляем его из каждого PlayerSpawn, иначе окна наслаиваются.
            end
        end)
    end)

    local function characterPending(ply)
        return IsValid(ply) and CH.PendingSelection[ply:SteamID64()] == true
    end

    hook.Add("StartCommand", "GRM_Char_BlockInput", function(ply, cmd)
        if not characterPending(ply) then return end
        ply:Freeze(true)
        cmd:ClearMovement()
        cmd:ClearButtons()
    end)

    hook.Add("PlayerUse", "GRM_Char_BlockUse", function(ply)
        if characterPending(ply) then return false end
    end)

    hook.Add("PlayerSpawnProp", "GRM_Char_BlockProp", function(ply)
        if characterPending(ply) then return false end
    end)

    hook.Add("CanTool", "GRM_Char_BlockTool", function(ply)
        if characterPending(ply) then return false end
    end)

    hook.Add("CanPlayerEnterVehicle", "GRM_Char_BlockVehicle", function(ply)
        if characterPending(ply) then return false end
    end)

    hook.Add("PlayerSay", "GRM_Char_BlockChat", function(ply)
        if characterPending(ply) then return "" end
    end)

    hook.Add("PlayerDisconnected", "GRM_Char_ClearPending", function(ply)
        if IsValid(ply) then
            CH.PendingSelection[ply:SteamID64()] = nil
            CH.PendingMandatory[ply:SteamID64()] = nil
            saveChars("disconnect")
        end
    end)

    net.Receive(NET_REQUEST, function(bits, ply)
        if not IsValid(ply) then return end
        if GRM.Net and GRM.Net.Guard then
            local allowed = GRM.Net.Guard(ply, "character.menu.request", { rate = .2, burst = 4, maxBits = 1024 }, { bits = bits })
            if not allowed then return end
        end
        if ply:GetNWBool("GRM_Arrested", false) then
            if GRM.Notify then GRM.Notify(ply, "Во время ареста меню персонажа недоступно.", 255, 100, 100) end
            return
        end
        local previewSlot = ""
        if bits and bits >= 8 then previewSlot = tostring(net.ReadString() or "") end
        if not previewSlot:match("^char[123]$") then previewSlot = activeSlot(ply) end
        -- Открытие персонажей через F4 /char переводит игрока в тот же
        -- безопасный режим выбора: мир затемняется и блокируется до подтверждения.
        setCharacterLock(ply, true, false)
        sendMenu(ply, previewSlot)
    end)

    net.Receive(NET_CANCEL,function(bits,ply)
        if not IsValid(ply)then return end;if GRM.Net and not GRM.Net.Guard(ply,"character.menu.cancel",{rate=.5,burst=1,maxBits=128},{bits=bits})then return end
        if ply:GetNWBool("GRM_Arrested", false) then
            closeMenu(ply)
            return
        end
        if CH.PendingMandatory[ply:SteamID64()] == true then
            -- Первичный вход нельзя закрыть крестиком: меню возвращается,
            -- игрок остаётся заблокирован до подтверждения персонажа.
            sendMenu(ply)
            return
        end
        -- Отмена не должна повторно применять/сохранять внешность:
        -- черновик жил только на клиенте, активный персонаж не менялся.
        setCharacterLock(ply, false, false)
        closeMenu(ply)
    end)

    net.Receive(NET_SAVE,function(bits,ply)
        if not IsValid(ply)then return end
        if GRM.Net and not GRM.Net.Guard(ply,"character.menu.save",{rate=1,burst=1,maxBits=262144},{bits=bits})then return end
        if(ply._grmCharacterSaveAt or 0)>CurTime()then return end;ply._grmCharacterSaveAt=CurTime()+.75
        if ply:GetNWBool("GRM_Arrested", false) then
            if GRM.Notify then GRM.Notify(ply, "Нельзя менять персонажа во время ареста.", 255, 100, 100) end
            return
        end
        local d = net.ReadTable() or {}
        if d.action == "select_slot" then
            local slot = tostring(d.slot or "char1")
            if not slot:match("^char[123]$") then return end
            local sameActive = slot == activeSlot(ply)
            local mandatory = CH.PendingMandatory[ply:SteamID64()] == true
            if sameActive and not mandatory then
                -- Anti-abuse: повторный выбор уже активного персонажа не
                -- вызывает Spawn, телепорт, reset inventory или повторный gear-flow.
                setCharacterLock(ply, false, false)
                closeMenu(ply)
                return
            end
            local ok = CH.SetActiveSlot(ply, slot, mandatory)
            if ok and hasCharacter(ply, slot) then closeMenu(ply) else sendMenu(ply) end
            return
        end
        local requestedSlot = tostring(d.slot or activeSlot(ply))
        local mandatory = CH.PendingMandatory[ply:SteamID64()] == true
        local sameActive = requestedSlot == activeSlot(ply)
        if not sameActive or mandatory then
            CH.SetActiveSlot(ply, requestedSlot, mandatory)
        end
        local wasNew = CH.Get(ply) == nil

        if d.name ~= nil then
            local ok, err = CH.SetName(ply, d.name, d.slot)
            if not ok then
                if GRM.Notify then GRM.Notify(ply, tostring(err), 255, 100, 100) end
            end
        end

        if isstring(d.model) and d.model ~= "" then
            local wardrobeRule = nil
            if d.wardrobe == true then
                local wardrobe = Entity(tonumber(d.wardrobeEnt) or 0)
                if not IsValid(wardrobe) or wardrobe:GetClass() ~= "grm_wardrobe"
                    or ply:GetPos():DistToSqr(wardrobe:GetPos()) > 220 * 220 then
                    if GRM.Notify then GRM.Notify(ply, "Гардероб недоступен или слишком далеко.", 255, 100, 100) end
                    return
                end
                local cfg = wardrobe.cfg or {}
                wardrobeRule = istable(cfg.modelRules) and cfg.modelRules[d.model] or {}
            end
            local bg = {}
            for g, v in pairs(d.bodygroups or {}) do
                local gi, vi = tonumber(g), tonumber(v)
                local groupRule = wardrobeRule and wardrobeRule.bodygroups and gi and wardrobeRule.bodygroups[gi]
                local allowed = not groupRule or groupRule == true
                    or (istable(groupRule) and groupRule[vi] ~= false)
                if gi and vi and vi ~= 0 and allowed then bg[gi] = vi end
            end
            local chosenSkin = tonumber(d.skin) or 0
            if wardrobeRule and wardrobeRule.allowSkin == false then chosenSkin = 0 end
            local ok, err = CH.ApplyAppearance(ply, { path = d.model, skin = chosenSkin, bodygroups = bg })
            if not ok and GRM.Notify then GRM.Notify(ply, tostring(err or "Не удалось применить внешность"), 255, 100, 100) end
            if ok and GRM.Notify then GRM.Notify(ply, "Внешность персонажа сохранена.", 100, 220, 100) end
        end

        if CH.Get(ply) ~= nil and isstring(d.name) and CH.ValidateName(d.name) then
            setCharacterLock(ply, false)
            if wasNew then
                hook.Run("GRM_CharacterChanged", ply, nil, CH.GetActiveKey(ply))
            end
            if wasNew and ply.Spawn then ply:Spawn() end
        end

        -- первичная регистрация: синхронизируем с фракционным спавном
        if wasNew and CH.Get(ply) ~= nil and _G.GetSpawnPointForPlayer then
            local pos, ang = _G.GetSpawnPointForPlayer(ply)
            if pos then
                ply:SetPos(pos)
                if ang then ply:SetEyeAngles(ang) end
            end
        end

        if CH.Get(ply) ~= nil and (not d.name or CH.ValidateName(d.name)) then
            timer.Simple(0.05, function() if IsValid(ply) then closeMenu(ply) end end)
        else
            sendMenu(ply)
        end
    end)

    -- команда /name Имя Фамилия ----------------------------------
    hook.Add("PlayerSay", "GRM_Char_NameCmd", function(ply, text)
        local t = string.Trim(text or "")
        local low = string.lower(t)
        if string.sub(low, 1, 6) == "/name " or string.sub(low, 1, 6) == "!name " then
            local ok, resOrErr = CH.SetName(ply, string.sub(t, 7))
            if ok then
                ply:PrintMessage(HUD_PRINTTALK, "[Персонаж] Игровое имя установлено: " .. tostring(CH.GetName(ply)))
            else
                ply:PrintMessage(HUD_PRINTTALK, "[Персонаж] " .. tostring(resOrErr))
            end
            return ""
        end
        if low == "/name" or low == "!name" then
            ply:PrintMessage(HUD_PRINTTALK, "[Персонаж] Ваше игровое имя: " .. (CH.GetName(ply) ~= "" and CH.GetName(ply) or "(не задано — откройте F4 → Персонаж)"))
            return ""
        end
    end)

    -- автосохранение уже не нужно (каждый Save пишет сразу), но подстрахуемся на выключении
    hook.Add("ShutDown", "GRM_Char_Save", function() saveChars("shutdown") end)

    print("[GRM Char] Ядро персонажей v" .. CH.Version .. " загружено (сервер)")
end

-- ============================================================
-- КЛИЕНТ
-- ============================================================
if CLIENT then
    surface.CreateFont("GRMChar_Big",    { font = "Roboto", size = 26, weight = 800, extended = true })
    surface.CreateFont("GRMChar_Title",  { font = "Roboto", size = 20, weight = 800, extended = true })
    surface.CreateFont("GRMChar_Sub",    { font = "Roboto", size = 15, weight = 600, extended = true })
    surface.CreateFont("GRMChar_Normal", { font = "Roboto", size = 13, weight = 500, extended = true })
    surface.CreateFont("GRMChar_Small",  { font = "Roboto", size = 12, weight = 400, extended = true })

    -- Плоская палитра (MapStudio-стиль): ограниченный набор слотов + свои кнопки.
    local C = {
        bg     = Color(13, 16, 24, 255),
        head   = Color(22, 28, 40, 255),
        panel  = Color(24, 30, 42, 245),
        panel2 = Color(30, 38, 52, 245),
        border = Color(70, 82, 105, 180),
        acc    = Color(75, 149, 255),
        accHov = Color(100, 170, 255, 255),
        green  = Color(46, 204, 113),
        red    = Color(225, 83, 83),
        yellow = Color(245, 200, 70),
        text   = Color(235, 239, 247),
        dim    = Color(150, 160, 175),
    }

    -----------------------------------------------------------
    -- Главное меню персонажа
    -----------------------------------------------------------
    local function openCharMenu(payload)
        local lp = LocalPlayer()
        if IsValid(lp) and lp:GetNWBool("GRM_Arrested", false) then
            notification.AddLegacy("Во время ареста меню персонажа недоступно.", NOTIFY_ERROR, 5)
            return
        end
        payload = istable(payload) and payload or {}
        if payload.wardrobe ~= true then payload.allowBodygroups = false end
        local char = istable(payload.char) and payload.char or nil
        local sections = istable(payload.sections) and payload.sections or {}
        local outfits = istable(payload.outfits) and payload.outfits or {}
        if #outfits == 0 then
            for _, sec in ipairs(sections) do
                for _, outfit in ipairs(sec.outfits or {}) do
                    local copy = table.Copy(outfit)
                    copy.provider = sec.id
                    copy.providerTitle = sec.title
                    outfits[#outfits + 1] = copy
                end
            end
        end
        local defaultOutfit = outfits[1]
        for _, outfit in ipairs(outfits) do
            if outfit.provider == "civilian" then defaultOutfit = outfit break end
        end
        local slots = istable(payload.slots) and payload.slots or {}
        local serverActiveSlot = tostring(payload.activeSlot or "char1")
        local activeSlot = tostring(payload.previewSlot or serverActiveSlot)
        CH._previewSlot=activeSlot;CH._actionPending=false;CH._actionKind=nil
        local refreshPreview, refreshSkinMax, rebuildBodygroups
        local skinSlider
        local bContinue, bSave

        local draft = {
            name = char and tostring(char.name or "") or "",
            model = char and tostring(char.model or "") or "",
            skin = char and tonumber(char.skin) or 0,
            bodygroups = char and table.Copy(char.bodygroups or {}) or {},
            wardrobeRule = {},
        }
        local matchedOutfit=nil
        for _,outfit in ipairs(outfits) do if string.lower(tostring(outfit.path or ""))==string.lower(draft.model) then matchedOutfit=outfit break end end
        if (draft.model=="" or not matchedOutfit) and defaultOutfit then
            draft.model=defaultOutfit.path; draft.skin=tonumber(defaultOutfit.skin) or 0; draft.bodygroups=table.Copy(defaultOutfit.bodygroups or {}); matchedOutfit=defaultOutfit
        end
        if matchedOutfit then draft.wardrobeRule=table.Copy(matchedOutfit.wardrobeRule or {}) end

        local isWardrobe = payload.wardrobe == true
        if IsValid(CH._frame) then CH._frame:Remove() CH._frame = nil end
        local f = vgui.Create("DFrame")
        CH._frame = f
        CH._frameMode = isWardrobe and "wardrobe" or "character"
        f.OnRemove = function()
            if CH._frame==f then CH._frame=nil;CH._frameMode=nil;CH._liveSignature=nil;CH._actionPending=false;CH._actionKind=nil end
        end
        if GRM.UI and GRM.UI.Track then GRM.UI.Track("character.appearance", f) end
        f:SetTitle("")
        local fw = math.min(1500, ScrW() - 60)
        local fh = math.min(880, ScrH() - 60)
        f:SetSize(fw, fh)
        f:Center()
        f:MakePopup()
        f:ShowCloseButton(false)
        f:SetDraggable(false)

        f.Paint = function(_, pw, ph)
            draw.RoundedBox(14, 0, 0, pw, ph, Color(8, 10, 16, 255))
            draw.RoundedBoxEx(14, 0, 0, pw, 64, C.head, true, true, false, false)
            local ttl = isWardrobe and tostring(payload.wardrobeTitle or "Гардероб") or (char and "МЕНЮ ПЕРСОНАЖА" or "СОЗДАНИЕ ПЕРСОНАЖА")
            draw.SimpleText(ttl, "GRMChar_Big", 26, 14, C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            local slotText = activeSlot == serverActiveSlot and ("активный слот: " .. activeSlot) or ("предпросмотр: " .. activeSlot .. "  •  активный: " .. serverActiveSlot)
            draw.SimpleText("GRM Identity v" .. CH.Version .. "   ·   " .. slotText, "GRMChar_Small", pw - 26, 26, C.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            draw.SimpleText("Слот и внешность применяются после подтверждения  •  "..(payload.factionName~="" and (payload.factionName.." / "..tostring(payload.factionRole).." / "..(payload.onDuty and "НА СЛУЖБЕ" or "ВНЕ СЛУЖБЫ")) or "ГРАЖДАНСКИЙ"), "GRMChar_Small", 26, 44, C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local x = vgui.Create("DButton", f)
        x:SetText("✕") x:SetFont("GRMChar_Sub") x:SetTextColor(color_white)
        x:SetPos(fw - 46, 16) x:SetSize(30, 28)
        x.Paint = function(self, pw, ph) draw.RoundedBox(5, 0, 0, pw, ph, self:IsHovered() and C.red or Color(45, 52, 68)) end
        x.DoClick=function()
            if CH._actionPending then return end
            if isWardrobe then f:Close() return end
            net.Start(NET_CANCEL) net.SendToServer()
            f:Close()
        end

        if isWardrobe and payload.isAdmin and payload.wardrobeEnt then
            local bCfg = vgui.Create("DButton", f)
            bCfg:SetText("⚙ Настройка гардероба") bCfg:SetFont("GRMChar_Normal") bCfg:SetTextColor(color_white)
            bCfg:SetPos(fw - 300, 18) bCfg:SetSize(230, 28)
            bCfg.Paint = function(self, pw, ph) draw.RoundedBox(6, 0, 0, pw, ph, self:IsHovered() and Color(255, 215, 100) or Color(190, 150, 40)) end
            bCfg.DoClick = function()
                net.Start("GRM_Wardrobe_CfgReq") net.WriteUInt(tonumber(payload.wardrobeEnt) or 0, 16) net.SendToServer()
                f:Close()
            end
        end

        -- ── Нижняя панель действий ──────────────────────────────────────
        local bot = vgui.Create("DPanel", f)
        bot:Dock(BOTTOM) bot:SetTall(64) bot:DockMargin(20, 0, 20, 14)
        bot:SetPaintBackground(false)
        local botHint = vgui.Create("DLabel", bot)
        botHint:Dock(LEFT) botHint:SetWide(520) botHint:DockMargin(4, 8, 0, 0)
        botHint:SetFont("GRMChar_Small") botHint:SetTextColor(C.dim)
        botHint:SetText("Слот определяет активного персонажа (счета, фракция, спавн). Внешность — модель, скин и бодигруппы.")

        -- ── Колонки ──────────────────────────────────────────────────────
        local left = vgui.Create("DPanel", f)
        left:Dock(LEFT) left:DockMargin(20, 78, 12, 10) left:SetWide(370)
        left:SetPaintBackground(false)

        local mid = vgui.Create("DPanel", f)
        mid:Dock(LEFT) mid:DockMargin(0, 78, 12, 10) mid:SetWide(330)
        mid:SetPaintBackground(false)

        local right = vgui.Create("DPanel", f)
        right:Dock(FILL) right:DockMargin(0, 78, 20, 10)
        right:SetPaintBackground(false)

        -- ── ЛЕВАЯ: имя ────────────────────────────────────────────────────
        local nameBox = vgui.Create("DPanel", left)
        nameBox:Dock(TOP) nameBox:SetTall(122) nameBox:DockMargin(0, 0, 0, 10)
        nameBox.Paint = function(_, pw, ph)
            draw.RoundedBox(8, 0, 0, pw, ph, C.panel)
            surface.SetDrawColor(C.border) surface.DrawOutlinedRect(0, 0, pw, ph, 1)
            draw.SimpleText("Игровое имя (RP Name)", "GRMChar_Sub", 14, 12, C.yellow, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        local nameEntry = vgui.Create("DTextEntry", nameBox)
        nameEntry:SetPos(14, 38) nameEntry:SetSize(left:GetWide() - 28, 32)
        nameEntry:SetFont("GRMChar_Sub") nameEntry:SetPlaceholderText("Имя Фамилия")
        nameEntry:SetText(draft.name) nameEntry:SetUpdateOnType(true)
        local nameHint = vgui.Create("DLabel", nameBox)
        nameHint:SetPos(14, 76) nameHint:SetSize(left:GetWide() - 28, 20) nameHint:SetFont("GRMChar_Normal") nameHint:SetTextColor(C.dim)
        local idHint = vgui.Create("DLabel", nameBox)
        idHint:SetPos(14, 96) idHint:SetSize(left:GetWide() - 28, 20) idHint:SetFont("GRMChar_Small") idHint:SetTextColor(C.dim)
        idHint:SetText("CharacterID: " .. tostring(payload.characterID or "будет создан"))
        local function updHint()
            local n = CH.ValidateName(draft.name)
            nameHint:SetText(n and ("✓ «" .. n .. "»") or ("Имя: минимум " .. (payload.nameMin or 3) .. " символа"))
            nameHint:SetTextColor(n and C.green or C.red)
        end
        nameEntry.OnChange = function() draft.name = nameEntry:GetValue() updHint() end
        updHint()

        -- ── ЛЕВАЯ: слоты (только не гардероб) ────────────────────────────
        local slotButtons = {}
        local function refreshSlotButtons()
            for _, sb in ipairs(slotButtons) do sb._selected = (sb._slotID == activeSlot) end
        end
        if not isWardrobe then
            local slotPanel = vgui.Create("DPanel", left)
            slotPanel:Dock(FILL) slotPanel:SetPaintBackground(false)
            local st = vgui.Create("DLabel", slotPanel)
            st:Dock(TOP) st:SetTall(26) st:SetFont("GRMChar_Sub") st:SetTextColor(C.yellow)
            st:SetText("Персонажи")
            local swrap = vgui.Create("DPanel", slotPanel)
            swrap:Dock(FILL) swrap:DockMargin(0, 4, 0, 0)
            swrap:SetPaintBackground(false)
            for i = 1, 3 do
                local info = slots[i] or { id = "char" .. i, index = i, exists = false }
                local b = vgui.Create("DButton", swrap)
                b:SetText("")
                b._slotID = info.id
                b._selected = (info.id == activeSlot)
                b._active = (info.id == serverActiveSlot)
                slotButtons[#slotButtons + 1] = b
                b:Dock(TOP) b:SetTall(98) b:DockMargin(0, 0, 0, 8)
                b.Paint = function(self, pw, ph)
                    local sel = self._selected == true
                    local has = info.exists == true
                    draw.RoundedBox(8, 0, 0, pw, ph, sel and Color(33, 52, 76) or C.panel)
                    surface.SetDrawColor(sel and C.acc or C.border)
                    surface.DrawOutlinedRect(0, 0, pw, ph, sel and 2 or 1)
                    local dot = sel and C.acc or (has and C.green or Color(80, 88, 102))
                    draw.RoundedBox(6, 14, 15, 12, 12, dot)
                    local nm = (has and (info.name ~= "" and info.name or ("Персонаж " .. i))) or ("Пустой слот " .. i)
                    draw.SimpleText(nm, "GRMChar_Sub", 38, 11, has and C.text or C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    draw.SimpleText(has and ("ID: " .. tostring(info.id)) or "Создать нового персонажа", "GRMChar_Small", 38, 33, C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    local detail = info.factionName ~= "" and (tostring(info.factionName) .. (info.factionRole ~= "" and (" • " .. tostring(info.factionRole)) or "")) or "Гражданский"
                    draw.SimpleText(detail, "GRMChar_Small", 38, 50, info.factionName ~= "" and C.yellow or C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    if has and info.model ~= "" then
                        local mdl = tostring(info.model):match("([^/]+)$") or tostring(info.model)
                        draw.SimpleText(mdl, "GRMChar_Small", 38, 67, C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    end
                    local state = self._active and (sel and "● АКТИВЕН" or "АКТИВЕН") or (sel and "● ПРОСМОТР" or "ВЫБРАТЬ")
                    draw.SimpleText(state, "GRMChar_Small", pw - 14, ph / 2, sel and C.acc or C.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                end
                b:SetEnabled(not (info.id == payload.activeSlot and payload.pending and payload.mandatory ~= true))
                b:SetTooltip(info.model ~= "" and ("Модель: " .. info.model) or "Персонаж ещё не создан")
                b.DoClick=function()
                    if info.id==activeSlot or CH._actionPending then return end;CH._actionPending=true;CH._actionKind="preview";CH._previewSlot=info.id
                    for _,sb in ipairs(slotButtons)do sb:SetEnabled(false)end
                    net.Start(NET_REQUEST);net.WriteString(info.id);net.SendToServer()
                    timer.Simple(4,function()if IsValid(f)and CH._frame==f and CH._actionPending then CH._actionPending=false;CH._actionKind=nil;for _,sb in ipairs(slotButtons)do if IsValid(sb)then sb:SetEnabled(true)end end end end)
                end
            end
        end

        -- ── СРЕДНЯЯ: внешность ────────────────────────────────────────────
        local midHead = vgui.Create("DLabel", mid)
        midHead:Dock(TOP) midHead:SetTall(26) midHead:SetFont("GRMChar_Sub") midHead:SetTextColor(C.yellow)
        midHead:SetText("Внешность")

        local osc = vgui.Create("DScrollPanel", mid)
        osc:Dock(FILL) osc:DockMargin(0, 2, 0, 0)
        local function modelLabel(path)
            local name = tostring(path or ""):match("([^/]+)$") or tostring(path or "")
            return name:gsub("%.mdl$", "")
        end
        local modelChoice=vgui.Create("DComboBox",mid)
        modelChoice:Dock(TOP); modelChoice:SetTall(34); modelChoice:DockMargin(0,4,0,8); modelChoice:SetFont("GRMChar_Normal")
        local modelInfo=vgui.Create("DLabel",mid); modelInfo:Dock(TOP); modelInfo:SetTall(70); modelInfo:SetWrap(true); modelInfo:SetFont("GRMChar_Normal"); modelInfo:SetTextColor(C.dim)
        local function chooseOutfit(entry)
            if not entry then return end
            draft.model=entry.path; draft.skin=tonumber(entry.skin) or 0; draft.bodygroups=table.Copy(entry.bodygroups or {}); draft.wardrobeRule=table.Copy(entry.wardrobeRule or {})
            modelInfo:SetText("Провайдер: "..tostring(entry.providerTitle or "Внешность").."\nМодель: "..tostring(entry.path or ""))
            refreshPreview(); refreshSkinMax(); skinSlider:SetValue(draft.skin); rebuildBodygroups(); timer.Simple(0.12,function()if rebuildBodygroups then rebuildBodygroups()end end)
        end
        for _,entry in ipairs(outfits) do
            local title=modelLabel(entry.path).."  •  "..tostring(entry.providerTitle or "Внешность")
            modelChoice:AddChoice(title,entry,string.lower(tostring(entry.path or ""))==string.lower(draft.model))
            if string.lower(tostring(entry.path or ""))==string.lower(draft.model) then modelInfo:SetText("Провайдер: "..tostring(entry.providerTitle or "Внешность").."\nМодель: "..tostring(entry.path or "")) end
        end
        modelChoice.OnSelect=function(_,_,_,entry) chooseOutfit(entry) end
        if #outfits==0 then modelChoice:SetValue("Нет доступных моделей"); modelInfo:SetText("Сервер не выдал моделей для текущей фракции/роли.") end

        -- ── ПРАВАЯ: превью + настройка ────────────────────────────────────
        local previewTitle = vgui.Create("DPanel", right)
        previewTitle:Dock(TOP) previewTitle:SetTall(44) previewTitle:DockMargin(0, 0, 0, 8)
        previewTitle.Paint = function(_, pw, ph)
            draw.RoundedBox(8, 0, 0, pw, ph, C.panel)
            draw.SimpleText("3D-превью", "GRMChar_Sub", 14, 14, C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText("модель · скин · бодигруппы", "GRMChar_Small", 14, 30, C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local previewBox = vgui.Create("DPanel", right)
        previewBox:Dock(FILL) previewBox:DockMargin(0, 0, 0, 10)
        previewBox.Paint = function(_, pw, ph)
            draw.RoundedBox(10, 0, 0, pw, ph, Color(11, 14, 21, 255))
            surface.SetDrawColor(C.border) surface.DrawOutlinedRect(0, 0, pw, ph, 1)
        end
        local preview = vgui.Create("DModelPanel", previewBox)
        preview:Dock(FILL) preview:DockMargin(6, 6, 6, 6)
        preview:SetFOV(36)
        preview:SetDirectionalLight(BOX_TOP, Color(255, 255, 255))
        preview:SetDirectionalLight(BOX_FRONT, Color(180, 200, 255))
        preview:SetAmbientLight(Color(90, 100, 125))
        function preview:LayoutEntity(ent) end

        refreshPreview = function()
            if not IsValid(preview) then return end
            if draft.model == "" then return end
            preview:SetModel(draft.model)
            local ent = preview:GetEntity()
            if IsValid(ent) then
                local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
                local center = (mins + maxs) * 0.5
                local height = math.max(32, maxs.z - mins.z)
                local width = math.max(32, maxs.y - mins.y)
                local fov = 36
                local distance = math.max(height * 1.65, width * 2.8, (height * 0.5) / math.tan(math.rad(fov * 0.5)) * 1.55)
                preview:SetFOV(fov)
                preview:SetLookAt(center + Vector(0, 0, height * 0.02))
                preview:SetCamPos(center + Vector(distance, 0, height * 0.03))
                ent:SetSkin(math.Clamp(tonumber(draft.skin) or 0, 0, 64))
                for i = 0, (ent:GetNumBodyGroups() or 1) - 1 do ent:SetBodygroup(i, 0) end
                for g, v in pairs(draft.bodygroups or {}) do ent:SetBodygroup(tonumber(g) or 0, tonumber(v) or 0) end
            end
            preview._grmPreviewSig = tostring(draft.model) .. "|" .. tostring(draft.skin)
        end
        function preview:Think()
            local sig = tostring(draft.model) .. "|" .. tostring(draft.skin)
            if sig ~= self._grmPreviewSig then refreshPreview() end
        end
        refreshPreview()
        timer.Simple(0, function() if IsValid(preview) then refreshPreview() end end)
        timer.Simple(0.15, function() if IsValid(preview) then refreshPreview() end end)

        local sets = vgui.Create("DPanel", right)
        sets:Dock(BOTTOM) sets:SetTall(132) sets:SetPaintBackground(false)

        local skinLbl = vgui.Create("DLabel", sets)
        skinLbl:Dock(TOP) skinLbl:SetTall(18) skinLbl:SetFont("GRMChar_Sub") skinLbl:SetTextColor(C.text)
        skinLbl:SetText("Скин")
        skinSlider = vgui.Create("DNumSlider", sets)
        skinSlider:Dock(TOP) skinSlider:SetTall(26)
        skinSlider:SetMin(0) skinSlider:SetDecimals(0) skinSlider:SetValue(draft.skin)
        skinSlider.OnValueChanged = function(_, val)
            draft.skin = math.floor(tonumber(val) or 0)
            local ent = IsValid(preview) and preview:GetEntity()
            if IsValid(ent) then ent:SetSkin(draft.skin) end
        end
        if payload.allowSkin == false then skinLbl:SetVisible(false) skinSlider:SetVisible(false) sets:SetTall(88) end
        if payload.allowBodygroups == false then sets:SetTall(payload.allowSkin == false and 4 or 60) end
        refreshSkinMax = function()
            local ent = IsValid(preview) and preview:GetEntity()
            local mx = IsValid(ent) and (ent:SkinCount() - 1) or 0
            skinSlider:SetMax(mx)
            if draft.skin > mx then draft.skin = mx skinSlider:SetValue(mx) end
            skinLbl:SetText("Скин (макс: " .. mx .. ")")
        end
        refreshSkinMax()

        local bgScroll = vgui.Create("DScrollPanel", sets)
        bgScroll:Dock(FILL) bgScroll:DockMargin(0, 4, 0, 0)
        if payload.allowBodygroups == false then bgScroll:SetVisible(false) end
        rebuildBodygroups = function()
            bgScroll:Clear()
            local ent = IsValid(preview) and preview:GetEntity()
            if not IsValid(ent) then return end
            local n = ent:GetNumBodyGroups() or 0
            for i = 0, n - 1 do
                local groupRule = draft.wardrobeRule and draft.wardrobeRule.bodygroups and draft.wardrobeRule.bodygroups[i]
                local count = ent:GetBodygroupCount(i) or 1
                local options = {}
                for value = 0, count - 1 do
                    local allowed = groupRule == nil or groupRule == true or (istable(groupRule) and groupRule[value] ~= false)
                    if allowed then options[#options + 1] = value end
                end
                if #options > 0 and count > 1 then
                    local row = vgui.Create("DPanel", bgScroll)
                    row:Dock(TOP) row:SetTall(24) row:DockMargin(0, 0, 0, 2)
                    row.Paint = function(_, pw, ph) draw.RoundedBox(4, 0, 0, pw, ph, C.panel2) end
                    local gname = ent:GetBodygroupName(i) or ("Группа " .. i)
                    local cur = tonumber(draft.bodygroups[i]) or options[1]
                    local function optionIndex(value)
                        for index, candidate in ipairs(options) do if candidate == value then return index end end
                        return 1
                    end
                    if optionIndex(cur) == 1 and options[1] ~= cur then cur = options[1] draft.bodygroups[i] = cur end
                    local bL = vgui.Create("DButton", row)
                    bL:SetText("◀") bL:SetFont("GRMChar_Normal") bL:SetTextColor(C.text)
                    bL:Dock(LEFT) bL:SetWide(30) bL:DockMargin(2, 2, 0, 2)
                    bL.Paint = function(self, pw, ph) draw.RoundedBox(4, 0, 0, pw, ph, self:IsHovered() and C.acc or Color(45, 52, 68)) end
                    local bR = vgui.Create("DButton", row)
                    bR:SetText("▶") bR:SetFont("GRMChar_Normal") bR:SetTextColor(C.text)
                    bR:Dock(RIGHT) bR:SetWide(30) bR:DockMargin(0, 2, 2, 2)
                    bR.Paint = function(self, pw, ph) draw.RoundedBox(4, 0, 0, pw, ph, self:IsHovered() and C.acc or Color(45, 52, 68)) end
                    local valLbl = vgui.Create("DLabel", row)
                    valLbl:Dock(FILL) valLbl:DockMargin(6, 0, 6, 0)
                    valLbl:SetFont("GRMChar_Normal") valLbl:SetTextColor(C.text)
                    local function upd()
                        local v = tonumber(draft.bodygroups[i]) or 0
                        valLbl:SetText(gname .. ":  " .. v .. " / " .. (count - 1) .. "  [доступно: " .. #options .. "]")
                        if IsValid(ent) then ent:SetBodygroup(i, v) end
                    end
                    bL.DoClick = function()
                        local index = optionIndex(tonumber(draft.bodygroups[i]) or options[1])
                        index = ((index - 2) % #options) + 1
                        draft.bodygroups[i] = options[index]
                        upd()
                    end
                    bR.DoClick = function()
                        local index = optionIndex(tonumber(draft.bodygroups[i]) or options[1])
                        index = (index % #options) + 1
                        draft.bodygroups[i] = options[index]
                        upd()
                    end
                    upd()
                end
            end
            if bgScroll:GetCanvas():GetTall() <= 2 then
                local none = vgui.Create("DLabel", bgScroll)
                none:Dock(TOP) none:SetText("У этой модели нет бодигрупп.")
                none:SetFont("GRMChar_Normal") none:SetTextColor(C.dim)
            end
        end
        rebuildBodygroups()
        timer.Simple(0.12, function() if IsValid(preview) then rebuildBodygroups() end end)

        -- ── Действия ─────────────────────────────────────────────────────
        local function submitCharacter()
            local nm = CH.ValidateName(draft.name)
            if not nm then
                Derma_Message("Укажите игровое имя (мин. " .. (payload.nameMin or 3) .. " символа).", "Персонаж", "Ок")
                return
            end
            if CH._actionPending then return end;CH._actionPending=true;CH._actionKind="save"
            if IsValid(bContinue)then bContinue:SetEnabled(false)end;if IsValid(bSave)then bSave:SetEnabled(false)end
            net.Start(NET_SAVE);net.WriteTable({slot=activeSlot or"char1",name=draft.name,model=draft.model,skin=draft.skin,bodygroups=draft.bodygroups,wardrobe=isWardrobe,wardrobeEnt=payload.wardrobeEnt,wardrobeRule=draft.wardrobeRule});net.SendToServer()
            timer.Simple(5,function()if IsValid(f)and CH._frame==f then CH._actionPending=false;CH._actionKind=nil;if IsValid(bContinue)then bContinue:SetEnabled(true)end;if IsValid(bSave)then bSave:SetEnabled(true)end end end)
        end

        bContinue = vgui.Create("DButton", bot)
        bContinue:SetText("▶ ПРОДОЛЖИТЬ") bContinue:SetFont("GRMChar_Sub") bContinue:SetTextColor(color_white)
        bContinue:Dock(RIGHT) bContinue:SetWide(210) bContinue:DockMargin(8, 8, 0, 8)
        bContinue:SetVisible(char ~= nil)
        bContinue.Paint = function(self, pw, ph) draw.RoundedBox(7, 0, 0, pw, ph, self:IsHovered() and C.accHov or C.acc) end
        bContinue.DoClick = submitCharacter

        bSave = vgui.Create("DButton", bot)
        bSave:SetText(char and (isWardrobe and "Сохранить" or "") or "Создать и выбрать") bSave:SetFont("GRMChar_Sub") bSave:SetTextColor(color_white)
        bSave:Dock(RIGHT) bSave:SetWide(250) bSave:DockMargin(8, 8, 0, 8)
        bSave:SetVisible(char == nil or isWardrobe)
        bSave.Paint = function(self, pw, ph) draw.RoundedBox(7, 0, 0, pw, ph, self:IsHovered() and Color(70, 220, 130) or C.green) end
        bSave.DoClick = submitCharacter
        if not char then bSave:SetText("Создать и выбрать (обязательно)") end
    end

    local function payloadSignature(p)
        local parts={tostring(p.wardrobe),tostring(p.wardrobeEnt),tostring(p.activeSlot),tostring(p.previewSlot),tostring(p.characterKey),tostring(p.factionName),tostring(p.factionRole),tostring(p.factionDepartment),tostring(p.onDuty),tostring(p.char and p.char.name),tostring(p.char and p.char.model)}
        for _,sl in ipairs(p.slots or{})do parts[#parts+1]=tostring(sl.id)..":"..tostring(sl.name)..":"..tostring(sl.model)..":"..tostring(sl.factionName)..":"..tostring(sl.factionRole)..":"..tostring(sl.factionDepartment)end
        for _,o in ipairs(p.outfits or {}) do parts[#parts+1]=tostring(o.path)..":"..tostring(o.skin) end
        return table.concat(parts,"|")
    end
    function CH.ReceiveMenuPayload(payload)
        payload=istable(payload)and payload or{};local sig=payloadSignature(payload);local mode=payload.wardrobe==true and"wardrobe"or"character"
        if IsValid(CH._frame)and CH._liveSignature==sig and CH._frameMode==mode then if CH._actionKind=="preview"then CH._actionPending=false;CH._actionKind=nil end return false end
        if CH._opening then CH._queuedPayload=payload return false end
        CH._opening=true;local ok,err=pcall(openCharMenu,payload);CH._opening=false
        if not ok then ErrorNoHalt("[GRM Character] menu build failed: "..tostring(err).."\n")return false end
        -- Set AFTER old frame removal: its OnRemove clears the previous signature.
        CH._liveSignature=sig;CH._actionPending=false;CH._actionKind=nil
        local queued=CH._queuedPayload;CH._queuedPayload=nil;if queued then timer.Simple(0,function()CH.ReceiveMenuPayload(queued)end)end
        return true
    end
    net.Receive(NET_OPEN,function() CH.ReceiveMenuPayload(net.ReadTable() or {}) end)
    timer.Create("GRM_Char_LiveRefresh",2,0,function()
        if IsValid(CH._frame)and CH._frameMode=="character"and not CH._actionPending and not CH._opening then
            net.Start(NET_REQUEST); net.WriteString(CH._previewSlot or "char1"); net.SendToServer()
        end
    end)

    net.Receive(NET_CLOSE, function()
        if IsValid(CH._frame) then
            CH._frame:Close()
            CH._frame = nil
        end
    end)

    -- Точка входа гардероба проходит через тот же singleton/dedup guard.
    CH._openFromWardrobe = CH.ReceiveMenuPayload

    function CH.OpenMenu()
        local lp = LocalPlayer()
        if IsValid(lp) and lp:GetNWBool("GRM_Arrested", false) then
            notification.AddLegacy("Во время ареста меню персонажа недоступно.", NOTIFY_ERROR, 5)
            return
        end
        if IsValid(CH._frame) and CH._frameMode == "character" then
            CH._frame:MakePopup(); CH._frame:MoveToFront(); return
        end
        if (CH._nextOpenRequest or 0) > RealTime() then return end
        CH._nextOpenRequest = RealTime() + .5
        local slot = CH._previewSlot or (IsValid(lp) and lp:GetNWString("GRM_CharacterID", "char1")) or "char1"
        net.Start(NET_REQUEST); net.WriteString(slot); net.SendToServer()
    end
    concommand.Add("grm_character", CH.OpenMenu)

    hook.Add("PlayerSayTransform", "GRM_Char_ChatCl", function(ply, text)
        if ply ~= LocalPlayer() then return end
        local msg = string.lower(string.Trim(text and (istable(text) and text[1] or text) or ""))
        if msg == "/char" or msg == "/chars" or msg == "!char" then
            CH.OpenMenu()
            if istable(text) then text[1] = "" end
            return true
        end
    end)

    local function clientCharacterPending()
        local lp = LocalPlayer()
        return IsValid(lp) and lp:GetNWBool("GRM_CharacterPending", false)
    end

    hook.Add("HUDPaintBackground", "GRM_Char_LockScreen", function()
        if not clientCharacterPending() then return end
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(0, 0, ScrW(), ScrH())
        draw.SimpleText("Выберите персонажа", "GRMChar_Title", ScrW() / 2, ScrH() - 84,
            Color(235, 235, 245), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Игровой мир заблокирован до подтверждения персонажа", "GRMChar_Normal",
            ScrW() / 2, ScrH() - 58, Color(145, 155, 175), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end)

    hook.Add("HUDShouldDraw", "GRM_Char_HideHUD", function()
        if clientCharacterPending() then return false end
    end)

    hook.Add("PlayerBindPress", "GRM_Char_BlockBinds", function(_, bind)
        if clientCharacterPending() then return true end
    end)

    hook.Add("SpawnMenuOpen", "GRM_Char_BlockSpawnMenu", function()
        if clientCharacterPending() then return false end
    end)

    hook.Add("ContextMenuOpen", "GRM_Char_BlockContextMenu", function()
        if clientCharacterPending() then return false end
    end)

    hook.Add("Think", "GRM_Char_CloseForeignMenus", function()
        if not clientCharacterPending() then return end
        if GRM.Mobile and GRM.Mobile.ClientIsOpen and GRM.Mobile.ClientIsOpen()
            and GRM.Mobile.ClientClose then
            GRM.Mobile.ClientClose()
        end
    end)

    print("[GRM Char] Ядро персонажей v" .. CH.Version .. " загружено (клиент)")
end
