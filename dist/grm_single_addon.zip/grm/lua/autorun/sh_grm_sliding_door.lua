--[[--------------------------------------------------------------------
    GRM Sliding Door (находка 173) — раздвижные двери из пропов

    Инструмент grm_sliding_door: ЛКМ по prop_physics → проп становится
    раздвижной дверью: плавно смещается на заданное число юнитов в
    выбранном направлении (влево/вправо/вперёд/назад/вверх) с настройкой
    скорости и плавности (ease in/out).

    СОВМЕСТИМОСТЬ С FFD:
      • проп получает isSlidingDoor=true и методы FadeActivate/
        FadeDeactivate/FadeToggle — те же, что у FFD Fading Door, поэтому
        Keypad/Scanner и FFD Link управляют раздвижной дверью без изменений;
      • GRM.FFDLink.Fade расширен: считает и sliding-двери.

    СОХРАНЕНИЕ:
      • duplicator-модификатор "GRM_SlidingDoor" (копия/сохранение карты);
      • перм-система: GRM.PermData.Extract/Apply["prop_physics"] дополнены
        sliding-веткой — /permadd сохраняет конфиг, после рестарта проп
        встаёт на место и работает как раздвижная дверь.
----------------------------------------------------------------------]]
if SERVER then AddCSLuaFile() end

GRM = GRM or {}
GRM.SlidingDoor = GRM.SlidingDoor or {}
local SD = GRM.SlidingDoor
SD.Version = "1.1.0"

SD.Doors = SD.Doors or {}   -- [ent] = data

-- Направления (локальные оси пропа)
SD.Directions = {
    left   = "Влево",
    right  = "Вправо",
    forward = "Вперёд",
    back   = "Назад",
    up     = "Вверх",
}

local function charKey(ply)
    if GRM.Identity and GRM.Identity.CharacterKey then return GRM.Identity.CharacterKey(ply) end
    return tostring(ply:SteamID64()) .. ":char1"
end

-- Применить механизм раздвижной двери к пропу
function SD.Apply(ply, ent, opts)
    if not IsValid(ent) then return false, "Нет энтити" end
    local cls = ent:GetClass()
    if cls ~= "prop_physics" and cls ~= "prop_dynamic" then
        return false, "Работает только с пропами (prop_physics/prop_dynamic)"
    end

    -- если уже раздвижная — просто перенастраиваем
    if not SD.IsSliding(ent) then
        ent:PhysicsInit(SOLID_VPHYSICS)
        ent:SetMoveType(MOVETYPE_NONE)
        ent:SetSolid(SOLID_VPHYSICS)
        local phys = ent:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(false)
            phys:Sleep()
        end
    end

    local data = {
        direction  = tostring(opts.direction or "left"),
        distance   = math.Clamp(tonumber(opts.distance) or 100, 10, 1000),
        speed      = math.Clamp(tonumber(opts.speed) or 120, 10, 2000),
        smooth     = math.Clamp(tonumber(opts.smooth) or 1.0, 0.1, 4.0),
        toggle     = opts.toggle == true or opts.toggle == 1,
        autoclose  = opts.autoclose == true or opts.autoclose == 1,
        closeTime  = math.max(0.5, tonumber(opts.closeTime) or 5),
        -- При perm-восстановлении владелец может быть офлайн: не теряем
        -- сохранённый CharacterKey только потому, что Player сейчас nil.
        owner      = IsValid(ply) and charKey(ply) or tostring(opts.owner or (ent.Sliding and ent.Sliding.owner) or ""),
        -- Звуки (находка 173d): пусто = нет звука; "открытие/закрытие" —
        -- когда дверь достигла конца/начала, "движение" — во время движения.
        soundOpen   = tostring(opts.soundOpen or ""),
        soundClose  = tostring(opts.soundClose or ""),
        soundMove   = tostring(opts.soundMove or ""),
    }

    ent.isSlidingDoor = true
    ent.Sliding = data
    ent.Sliding_BasePos = ent:GetPos()
    ent.Sliding_OpenPos = ent:GetPos() + SD.OffsetFor(ent, data)
    ent.Sliding_Open = false
    ent.Sliding_Progress = 0          -- 0..1 (0 = закрыто, 1 = открыто)
    ent.Sliding_CloseAt = 0

    -- Методы, совместимые с FFD (Keypad/Scanner/FFD Link зовут их)
    ent.FadeActivate = function() SD.SetOpen(ent, true) end
    ent.FadeDeactivate = function() SD.SetOpen(ent, false) end
    ent.FadeToggle = function() SD.SetOpen(ent, not ent.Sliding_Open) end

    ent:SetNWBool("FFD_IsDoor", true)  -- подсветка в FFD Link

    SD.Doors[ent] = data

    if not opts.skipDupe then
        duplicator.StoreEntityModifier(ent, "GRM_SlidingDoor", {
            direction = data.direction, distance = data.distance,
            speed = data.speed, smooth = data.smooth,
            toggle = data.toggle, autoclose = data.autoclose, closeTime = data.closeTime,
            soundOpen = data.soundOpen, soundClose = data.soundClose, soundMove = data.soundMove,
        })
    end

    return true, "Раздвижная дверь настроена"
end

-- Смещение для конфигурации (локальные оси пропа)
function SD.OffsetFor(ent, data)
    local dir = tostring(data.direction or "left")
    local d = tonumber(data.distance) or 100
    local ang = IsValid(ent) and ent:GetAngles() or Angle(0, 0, 0)
    if dir == "left" then return ang:Right() * -d
    elseif dir == "right" then return ang:Right() * d
    elseif dir == "forward" then return ang:Forward() * d
    elseif dir == "back" then return ang:Forward() * -d
    elseif dir == "up" then return Vector(0, 0, d)
    end
    return ang:Right() * -d
end

function SD.IsSliding(ent)
    return IsValid(ent) and ent.isSlidingDoor == true
end

-- Снять механизм (проп возвращается в исходную позицию)
function SD.Remove(ent)
    if not SD.IsSliding(ent) then return false end
    ent:SetPos(ent.Sliding_BasePos or ent:GetPos())
    ent.isSlidingDoor = nil
    ent.Sliding = nil
    ent.Sliding_Open = nil
    ent.Sliding_Progress = nil
    ent.Sliding_BasePos = nil
    ent.Sliding_OpenPos = nil
    ent.FadeActivate = nil
    ent.FadeDeactivate = nil
    ent.FadeToggle = nil
    ent:SetNWBool("FFD_IsDoor", false)
    SD.Doors[ent] = nil
    return true
end

-- Открыть/закрыть (вызывается FadeActivate/FadeDeactivate и FFD Link)
function SD.SetOpen(ent, open)
    if not SD.IsSliding(ent) then return end
    ent.Sliding_Open = open == true
    if open then
        ent.Sliding_CloseAt = 0
    elseif ent.Sliding and ent.Sliding.autoclose then
        ent.Sliding_CloseAt = 0 -- автозакрытие управляется таймером Think
    end
end

-- ============================================================
-- PERM: собственный autorun-делегат (не зависит от загрузки STOOL FFD)
-- ============================================================
if SERVER then
    GRM.PermData = GRM.PermData or { Extract = {}, Apply = {} }
    GRM.PermData.Extract = GRM.PermData.Extract or {}
    GRM.PermData.Apply = GRM.PermData.Apply or {}

    local function extractSliding(ent)
        if not (IsValid(ent) and ent.isSlidingDoor and istable(ent.Sliding)) then return nil end
        local s = ent.Sliding
        return { sliding = {
            direction = tostring(s.direction or "left"),
            distance = tonumber(s.distance) or 100,
            speed = tonumber(s.speed) or 120,
            smooth = tonumber(s.smooth) or 1,
            toggle = s.toggle == true,
            autoclose = s.autoclose == true,
            closeTime = tonumber(s.closeTime) or 5,
            owner = tostring(s.owner or ""),
            soundOpen = tostring(s.soundOpen or ""),
            soundClose = tostring(s.soundClose or ""),
            soundMove = tostring(s.soundMove or ""),
        } }
    end
    local function applySliding(ent, payload)
        local d = istable(payload) and payload.sliding or nil
        if not istable(d) then return end
        SD.Apply(nil, ent, {
            direction = d.direction, distance = d.distance,
            speed = d.speed, smooth = d.smooth,
            toggle = d.toggle, autoclose = d.autoclose, closeTime = d.closeTime,
            owner = d.owner,
            soundOpen = d.soundOpen, soundClose = d.soundClose, soundMove = d.soundMove,
            skipDupe = true,
        })
    end
    if isfunction(GRM.PermData.AddExtract) then GRM.PermData.AddExtract("prop_physics", extractSliding)
    else GRM.PermData.Extract["prop_physics"] = extractSliding end
    if isfunction(GRM.PermData.AddApply) then GRM.PermData.AddApply("prop_physics", applySliding)
    else GRM.PermData.Apply["prop_physics"] = applySliding end
end

-- ============================================================
-- СЕРВЕР: единый Think-хук анимации
-- ============================================================
if SERVER then
    -- Плавность: ease in/out (smooth=1 — линейно, больше — мягче)
    local function ease(t, s)
        s = tonumber(s) or 1
        if s <= 0.1 then return t end
        -- smoothstep с настраиваемой кривизной
        local x = math.Clamp(t, 0, 1)
        local k = math.max(0.1, s)
        return (x ^ (1 / k)) / ((x ^ (1 / k)) + ((1 - x) ^ (1 / k)))
    end

    local lastThink = 0
    hook.Add("Think", "GRM_SlidingDoor_Think", function()
        local now = CurTime()
        local dt = math.min(0.1, now - lastThink)
        lastThink = now
        if dt <= 0 then return end

        for ent, data in pairs(SD.Doors) do
            if not IsValid(ent) then
                SD.Doors[ent] = nil
            else
                local base = ent.Sliding_BasePos
                local openPos = ent.Sliding_OpenPos
                if base and openPos then
                    local target = ent.Sliding_Open and 1 or 0
                    local cur = ent.Sliding_Progress or 0
                    -- скорость в юнитах/сек → приращение прогресса
                    local dist = base:Distance(openPos)
                    local rate = dist > 0 and ((tonumber(data.speed) or 120) / dist) or 1
                    local step = rate * dt
                    local next = cur
                    if cur < target then next = math.min(target, cur + step)
                    elseif cur > target then next = math.max(target, cur - step) end
                    ent.Sliding_Progress = next
                    -- плавная позиция
                    local e = ease(next, data.smooth)
                    ent:SetPos(base + (openPos - base) * e)

                    -- Звуки (находка 173d): в движении, при открытии, при закрытии
                    local moving = math.abs(next - cur) > 0.0001
                    local soundOpen = tostring(data.soundOpen or "")
                    local soundClose = tostring(data.soundClose or "")
                    local soundMove = tostring(data.soundMove or "")
                    if moving and soundMove ~= "" then
                        if (ent.Sliding_SndMove or 0) <= now then
                            ent.Sliding_SndMove = now + 0.6  -- не чаще 1.6/сек
                            ent:EmitSound(soundMove, 70, 100)
                        end
                    end
                    -- Открытие: один раз при достижении конца (переход 0→1)
                    if next >= 1 and not ent.Sliding_WasOpen and soundOpen ~= "" then
                        ent:EmitSound(soundOpen, 75, 100)
                    end
                    -- Закрытие: один раз при достижении начала (переход 1→0),
                    -- флаг «был открыт» держим до самого конца, чтобы не потерять момент
                    if next <= 0 and ent.Sliding_WasEverOpen and soundClose ~= "" then
                        ent:EmitSound(soundClose, 75, 100)
                    end
                    if next >= 1 then ent.Sliding_WasOpen = true ent.Sliding_WasEverOpen = true
                    elseif next <= 0 then ent.Sliding_WasOpen = false ent.Sliding_WasEverOpen = false end

                    -- автозакрытие
                    if ent.Sliding_Open and data.autoclose then
                        if ent.Sliding_CloseAt == 0 and next >= 1 then
                            ent.Sliding_CloseAt = now + (tonumber(data.closeTime) or 5)
                        elseif ent.Sliding_CloseAt > 0 and now >= ent.Sliding_CloseAt then
                            SD.SetOpen(ent, false)
                        end
                    end
                end
            end
        end
    end)

    -- Очистка реестра при удалении
    hook.Add("EntityRemoved", "GRM_SlidingDoor_Cleanup", function(ent)
        if ent and ent.isSlidingDoor then
            SD.Doors[ent] = nil
        end
    end)

    -- Duplicator: восстановление
    duplicator.RegisterEntityModifier("GRM_SlidingDoor", function(ply, ent, data)
        if IsValid(ent) then
            SD.Apply(ply, ent, {
                direction = data.direction, distance = data.distance,
                speed = data.speed, smooth = data.smooth,
                toggle = data.toggle, autoclose = data.autoclose, closeTime = data.closeTime,
                soundOpen = data.soundOpen, soundClose = data.soundClose, soundMove = data.soundMove,
            })
        end
    end)

    print("[GRM SlidingDoor] server v" .. SD.Version .. " loaded")
end
